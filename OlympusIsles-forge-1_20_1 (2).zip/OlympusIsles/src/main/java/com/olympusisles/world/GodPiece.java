package com.olympusisles.world;

import com.olympusisles.ModRegistry;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.TemplateStructurePiece;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;
import net.minecraft.world.level.levelgen.structure.templatesystem.BlockIgnoreProcessor;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplateManager;

/** Una pieza de plantilla: o bien la isla voladora, o bien el monumento del suelo. Sin rotación. */
public class GodPiece extends TemplateStructurePiece {
    private final boolean island;

    public GodPiece(StructureTemplateManager manager, ResourceLocation id, BlockPos pos, boolean island) {
        super(ModRegistry.GOD_PIECE.get(), 0, manager, id, id.toString(), makeSettings(), pos);
        this.island = island;
    }

    public GodPiece(StructureTemplateManager manager, CompoundTag tag) {
        super(ModRegistry.GOD_PIECE.get(), tag, manager, id -> makeSettings());
        this.island = tag.getBoolean("Island");
    }

    private static StructurePlaceSettings makeSettings() {
        return new StructurePlaceSettings()
                .setRotation(Rotation.NONE)
                .setMirror(Mirror.NONE)
                .addProcessor(BlockIgnoreProcessor.STRUCTURE_BLOCK);
    }

    public boolean isIsland() {
        return island;
    }

    @Override
    protected void addAdditionalSaveData(StructurePieceSerializationContext context, CompoundTag tag) {
        super.addAdditionalSaveData(context, tag);
        tag.putBoolean("Island", island);
    }

    @Override
    protected void handleDataMarker(String marker, BlockPos pos, ServerLevelAccessor level, RandomSource random,
                                    BoundingBox box) {
    }
}
