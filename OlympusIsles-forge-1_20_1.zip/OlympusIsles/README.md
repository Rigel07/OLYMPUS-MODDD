# Islas del Olimpo (mod para Minecraft Forge 1.20.1)

Islas voladoras enormes de los antiguos dioses griegos. Por ahora hay cuatro: **Zeus, Afrodita, Hades y Poseidón**.

## Subirlo a GitHub (se descomprime y compila solo)
1. Crea un repositorio nuevo en GitHub.
2. *Add file > Create new file*, nombre `.github/workflows/build.yml`, y pega el contenido del archivo **build.yml** que viene aparte. Commit.
3. *Add file > Upload files* y arrastra el **.zip tal cual**. Commit.
4. Pestaña **Actions**: se extrae el zip, se guarda el código en el repositorio y se compila.
   Descarga el .jar en el artefacto **mod-jar** y ponlo en la carpeta `mods` de Forge 1.20.1 (47.3.0 o superior).
   Si subes un zip nuevo, el workflow lo vuelve a extraer y compilar solo.

## Cómo se juega
1. **Encuentra el libro**: el "Libro de Zeus" (y los de Afrodita, Hades y Poseidón) aparece con poca probabilidad (6-8 %)
   en cofres de mazmorras, minas abandonadas, templos del desierto y la selva, bibliotecas y pasillos de fortalezas,
   mansiones, tesoros enterrados, ciudades antiguas, templos de aldea, naufragios, ruinas submarinas, puestos de
   saqueadores e iglús. Dentro hay un poco de leyenda y la **contraseña** de ese dios en tu mundo
   (sale de la semilla, y es la misma para todas las islas de ese dios).
2. **Localiza una isla**: es muy raro verlas (una cada 1.500-2.000 bloques por dios, solo sobre tierra firme). Brillan en lo alto, a unos 215 bloques de altura.
3. **Bajo la isla hay un monumento**: un monolito entre columnas. Clic derecho en él y escribe la contraseña.
   Te teletransporta a la isla, junto a la estatua del dios.
4. **El primero que entra es el dueño** de la isla. Los demás no pueden entrar (una barrera invisible los devuelve al suelo)
   hasta que el dueño les dé permiso con `/olympus trust <jugador>`.
5. **La estatua**: toca cualquier bloque de la gran estatua para sintonizarla. Después, **agachado + clic derecho** en la
   estatua abre el menú de viaje: bajar al monumento o ir a la estatua de cualquier otra isla que ya hayas sintonizado.
6. En la isla de un dios: eres **inmortal**, ningún mob hostil entra, tienes la **bendición** del dios
   (Zeus: velocidad y prisa; Afrodita: suerte y salto; Hades: resistencia al fuego, visión nocturna y fuerza;
   Poseidón: respirar bajo el agua, gracia del delfín y poder del conducto) y, si te caes por el borde, el dios te devuelve a su isla.

## Las islas
- **Zeus**: plaza de mármol con la estatua colosal del rey del Olimpo y su rayo, gran templo períptero, tesoro circular,
  anfiteatro, avenida con pararrayos y propileo, estanque con fuente, olivos y cipreses.
- **Afrodita**: jardines de cerezos y rosas, estatua sobre un pedestal con estanque, templo circular rosa, lago en forma de corazón con puente,
  pérgolas floridas, puerta del amor y templetes.
- **Hades**: terreno oscuro, estatua sobre trono con Cerbero, foso de lava con cuatro puentes, templo de basalto,
  puertas del Tártaro con cadenas, fosos de lava, árboles muertos, tumbas, huesos y fuegos de almas.
- **Poseidón**: playas y palmeras, estatua con el tridente rodeada de agua, templo de prismarina, laguna con muelle, barco y coral, y un faro.
Cada isla tiene un **cofre con la historia del dios** (un libro dentro del templo) y cofres de botín temático.

## Comandos
- `/olympus info`: dueño e invitados de la isla en la que estás (o junto a su monumento).
- `/olympus trust <jugador>` y `/olympus untrust <jugador>`: solo el dueño.
- Operadores: `/olympus book <dios>` (te da el libro), `/olympus password <dios>`, `/olympus unclaim`.
  Un operador en creativo atraviesa la barrera.

## Probarlo rápido
- `/locate structure olympus_isles:zeus_island` (también `aphrodite_island`, `hades_island`, `poseidon_island`).
- `/place structure olympus_isles:zeus_island` crea monumento e isla donde estés.
- `/olympus book zeus` y clic derecho en el monumento.
- Cada isla pesa unos 300.000 bloques: la primera vez que se genera o se carga puede notarse un pequeño tirón.

## Ajustes
- `data/olympus_isles/worldgen/structure_set/*.json`: cada cuánto aparecen (`spacing`, `separation`).
- `data/olympus_isles/tags/worldgen/biome/has_god_island.json`: biomas permitidos para el monumento.
- `data/olympus_isles/loot_modifiers/*.json`: dónde y con qué probabilidad aparece cada libro.
- `data/olympus_isles/loot_tables/chests/*_treasure.json`: el botín de cada isla.
- `tools/`: scripts de Python que dibujan las islas y generan las plantillas (`python tools/resources.py`; necesita Pillow).
  `IslandConstants.java` y `tools/designs.py` comparten las medidas: si cambias unas, cambia las otras.
