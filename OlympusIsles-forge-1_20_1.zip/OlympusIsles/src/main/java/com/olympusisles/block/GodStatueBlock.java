package com.olympusisles.block;

import com.olympusisles.God;
import com.olympusisles.island.IslandManager;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Mármol de las estatuas colosales. Tocar cualquier bloque de la estatua sintoniza su punto de
 * teletransporte; agachado, abre el viaje a las estatuas de otras islas ya sintonizadas.
 */
public class GodStatueBlock extends Block {
    public static final EnumProperty<God> GOD = EnumProperty.create("god", God.class);

    public GodStatueBlock(Properties properties) {
        super(properties);
        registerDefaultState(this.stateDefinition.any().setValue(GOD, God.ZEUS));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(GOD);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand,
                                 BlockHitResult hit) {
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (player instanceof ServerPlayer serverPlayer) {
            IslandManager.onStatueUsed(serverPlayer, pos, state.getValue(GOD));
        }
        return InteractionResult.CONSUME;
    }
}
