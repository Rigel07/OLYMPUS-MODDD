package com.olympusisles.block;

import com.olympusisles.God;
import com.olympusisles.island.IslandManager;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.BlockHitResult;

/** El monolito bajo cada isla: aquí se escribe la contraseña del dios para ascender. */
public class PasswordMonumentBlock extends Block {
    public static final EnumProperty<God> GOD = EnumProperty.create("god", God.class);

    public PasswordMonumentBlock(Properties properties) {
        super(properties);
        registerDefaultState(this.stateDefinition.any().setValue(GOD, God.ZEUS));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(GOD);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand,
                                 BlockHitResult hit) {
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (player instanceof ServerPlayer serverPlayer) {
            IslandManager.onMonumentUsed(serverPlayer, pos, state.getValue(GOD));
        }
        return InteractionResult.CONSUME;
    }

    /** Un hilo de destellos sube hacia la isla. */
    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (random.nextInt(3) == 0) {
            level.addParticle(ParticleTypes.END_ROD,
                    pos.getX() + 0.5D + (random.nextDouble() - 0.5D) * 0.4D,
                    pos.getY() + 1.0D,
                    pos.getZ() + 0.5D + (random.nextDouble() - 0.5D) * 0.4D,
                    0.0D, 0.12D, 0.0D);
        }
    }
}
