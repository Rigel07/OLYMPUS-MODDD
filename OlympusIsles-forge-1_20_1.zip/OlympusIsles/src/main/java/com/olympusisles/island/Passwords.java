package com.olympusisles.island;

import com.olympusisles.God;
import net.minecraft.server.level.ServerLevel;

import java.util.Random;

/** La contraseña de cada dios es distinta en cada mundo (sale de la semilla) y es la misma para todas sus islas. */
public final class Passwords {
    private Passwords() {}

    public static String get(ServerLevel level, God god) {
        long seed = level.getServer().overworld().getSeed();
        Random random = new Random(seed * 31L + (god.ordinal() + 1) * 0x9E3779B97F4A7C15L);
        String[] words = god.words();
        return words[random.nextInt(words.length)] + "-" + (1000 + random.nextInt(9000));
    }
}
