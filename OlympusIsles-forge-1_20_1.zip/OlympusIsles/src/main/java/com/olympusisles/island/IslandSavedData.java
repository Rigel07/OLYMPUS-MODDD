package com.olympusisles.island;

import com.olympusisles.God;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.LongArrayTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.saveddata.SavedData;
import org.jetbrains.annotations.Nullable;

import com.olympusisles.world.IslandConstants;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Dueños, invitados y estatuas sintonizadas por jugador. Se guarda en el mundo. */
public class IslandSavedData extends SavedData {
    private static final String NAME = "olympus_isles_islands";

    public static class Island {
        public final long key;
        public final God god;
        public int minX, minY, minZ, maxX, maxZ;
        public int spawnX, spawnY, spawnZ;
        public int groundX, groundY, groundZ;
        @Nullable
        public UUID owner;
        public String ownerName = "";
        public final Set<UUID> trusted = new LinkedHashSet<>();

        Island(long key, God god) {
            this.key = key;
            this.god = god;
        }

        public boolean isAuthorized(UUID id) {
            return owner != null && (owner.equals(id) || trusted.contains(id));
        }

        public boolean containsXZ(double x, double z) {
            return x >= minX && x < maxX + 1 && z >= minZ && z < maxZ + 1;
        }

        CompoundTag toTag() {
            CompoundTag tag = new CompoundTag();
            tag.putLong("Key", key);
            tag.putString("God", god.getSerializedName());
            tag.putIntArray("Box", new int[]{minX, minY, minZ, maxX, maxZ});
            tag.putIntArray("Spawn", new int[]{spawnX, spawnY, spawnZ});
            tag.putIntArray("Ground", new int[]{groundX, groundY, groundZ});
            if (owner != null) {
                tag.putUUID("Owner", owner);
            }
            tag.putString("OwnerName", ownerName);
            ListTag list = new ListTag();
            for (UUID id : trusted) {
                list.add(NbtUtils.createUUID(id));
            }
            tag.put("Trusted", list);
            return tag;
        }

        static Island fromTag(CompoundTag tag) {
            Island island = new Island(tag.getLong("Key"), God.byId(tag.getString("God")));
            int[] box = tag.getIntArray("Box");
            if (box.length == 5) {
                island.minX = box[0];
                island.minY = box[1];
                island.minZ = box[2];
                island.maxX = box[3];
                island.maxZ = box[4];
            }
            int[] spawn = tag.getIntArray("Spawn");
            if (spawn.length == 3) {
                island.spawnX = spawn[0];
                island.spawnY = spawn[1];
                island.spawnZ = spawn[2];
            }
            int[] ground = tag.getIntArray("Ground");
            if (ground.length == 3) {
                island.groundX = ground[0];
                island.groundY = ground[1];
                island.groundZ = ground[2];
            }
            if (tag.hasUUID("Owner")) {
                island.owner = tag.getUUID("Owner");
            }
            island.ownerName = tag.getString("OwnerName");
            ListTag list = tag.getList("Trusted", Tag.TAG_INT_ARRAY);
            for (int i = 0; i < list.size(); i++) {
                island.trusted.add(NbtUtils.loadUUID(list.get(i)));
            }
            return island;
        }
    }

    private final Map<Long, Island> islands = new HashMap<>();
    private final Map<UUID, Set<Long>> attuned = new HashMap<>();

    public static IslandSavedData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(IslandSavedData::load, IslandSavedData::new, NAME);
    }

    public static IslandSavedData load(CompoundTag tag) {
        IslandSavedData data = new IslandSavedData();
        ListTag list = tag.getList("Islands", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            Island island = Island.fromTag(list.getCompound(i));
            data.islands.put(island.key, island);
        }
        CompoundTag att = tag.getCompound("Attuned");
        for (String key : att.getAllKeys()) {
            Set<Long> set = new HashSet<>();
            for (long value : att.getLongArray(key)) {
                set.add(value);
            }
            data.attuned.put(UUID.fromString(key), set);
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (Island island : islands.values()) {
            list.add(island.toTag());
        }
        tag.put("Islands", list);
        CompoundTag att = new CompoundTag();
        for (Map.Entry<UUID, Set<Long>> entry : attuned.entrySet()) {
            att.put(entry.getKey().toString(), new LongArrayTag(entry.getValue().stream().mapToLong(Long::longValue).toArray()));
        }
        tag.put("Attuned", att);
        return tag;
    }

    public Island getOrCreate(long key, God god, BoundingBox islandBox, BoundingBox monumentBox) {
        Island island = islands.get(key);
        if (island == null) {
            island = new Island(key, god);
            island.minX = islandBox.minX();
            island.minY = islandBox.minY();
            island.minZ = islandBox.minZ();
            island.maxX = islandBox.maxX();
            island.maxZ = islandBox.maxZ();
            island.spawnX = islandBox.minX() + IslandConstants.SPAWN_X;
            island.spawnY = islandBox.minY() + IslandConstants.SPAWN_Y;
            island.spawnZ = islandBox.minZ() + IslandConstants.SPAWN_Z;
            island.groundX = monumentBox.minX() + IslandConstants.MON_SPAWN_X;
            island.groundY = monumentBox.minY() + IslandConstants.MON_SPAWN_Y;
            island.groundZ = monumentBox.minZ() + IslandConstants.MON_SPAWN_Z;
            islands.put(key, island);
            setDirty();
        }
        return island;
    }

    @Nullable
    public Island get(long key) {
        return islands.get(key);
    }

    public Collection<Island> all() {
        return islands.values();
    }

    /** @return true si la estatua no estaba sintonizada todavía. */
    public boolean attune(UUID player, long key) {
        boolean added = attuned.computeIfAbsent(player, id -> new HashSet<>()).add(key);
        if (added) {
            setDirty();
        }
        return added;
    }

    public Set<Long> attunedBy(UUID player) {
        return attuned.getOrDefault(player, Set.of());
    }

    public void markDirty() {
        setDirty();
    }
}
