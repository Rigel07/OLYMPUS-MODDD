package com.olympusisles.island;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.olympusisles.God;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

import java.util.List;
import java.util.UUID;

/** /olympus trust|untrust|info (dueño) y /olympus book|password|unclaim (operadores). */
public final class IslandCommands {
    private IslandCommands() {}

    private static final List<String> GODS = List.of("zeus", "aphrodite", "hades", "poseidon");

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("olympus")
                .then(Commands.literal("info").executes(ctx -> info(ctx.getSource())))
                .then(Commands.literal("trust").then(Commands.argument("player", EntityArgument.player())
                        .executes(ctx -> trust(ctx.getSource(), EntityArgument.getPlayer(ctx, "player"), true))))
                .then(Commands.literal("untrust").then(Commands.argument("player", EntityArgument.player())
                        .executes(ctx -> trust(ctx.getSource(), EntityArgument.getPlayer(ctx, "player"), false))))
                .then(Commands.literal("book").requires(source -> source.hasPermission(2))
                        .then(Commands.argument("god", StringArgumentType.word())
                                .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(GODS, builder))
                                .executes(ctx -> book(ctx.getSource(), StringArgumentType.getString(ctx, "god")))))
                .then(Commands.literal("password").requires(source -> source.hasPermission(2))
                        .then(Commands.argument("god", StringArgumentType.word())
                                .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(GODS, builder))
                                .executes(ctx -> password(ctx.getSource(), StringArgumentType.getString(ctx, "god")))))
                .then(Commands.literal("unclaim").requires(source -> source.hasPermission(2))
                        .executes(ctx -> unclaim(ctx.getSource()))));
    }

    private static IslandManager.Located here(ServerPlayer player) {
        return IslandManager.locate(player.serverLevel(), player.blockPosition());
    }

    private static int info(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        IslandManager.Located loc = here(player);
        if (loc == null) {
            player.displayClientMessage(Component.translatable("message.olympus_isles.no_island_here"), false);
            return 0;
        }
        IslandSavedData.Island island = IslandManager.island(player.serverLevel(), loc);
        String owner = island.owner == null ? "-" : island.ownerName;
        player.displayClientMessage(Component.translatable("command.olympus_isles.info",
                Component.translatable(island.god.langKey()), owner, island.trusted.size()), false);
        return 1;
    }

    private static int trust(CommandSourceStack source, ServerPlayer target, boolean add) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        IslandManager.Located loc = here(player);
        if (loc == null) {
            player.displayClientMessage(Component.translatable("message.olympus_isles.no_island_here"), false);
            return 0;
        }
        ServerLevel level = player.serverLevel();
        IslandSavedData data = IslandSavedData.get(level.getServer());
        IslandSavedData.Island island = IslandManager.island(level, loc);
        UUID id = player.getUUID();
        if (island.owner == null || (!island.owner.equals(id) && !player.hasPermissions(2))) {
            player.displayClientMessage(Component.translatable("command.olympus_isles.not_owner"), false);
            return 0;
        }
        if (add) {
            island.trusted.add(target.getUUID());
        } else {
            island.trusted.remove(target.getUUID());
        }
        data.markDirty();
        player.displayClientMessage(Component.translatable(add ? "command.olympus_isles.trusted" : "command.olympus_isles.untrusted",
                target.getDisplayName()), false);
        if (add) {
            target.displayClientMessage(Component.translatable("command.olympus_isles.you_are_trusted",
                    Component.translatable(island.god.langKey()), island.ownerName), false);
        }
        return 1;
    }

    private static int book(CommandSourceStack source, String godId) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ItemStack book = BookFactory.create(player.serverLevel(), God.byId(godId));
        if (!player.getInventory().add(book)) {
            player.drop(book, false);
        }
        return 1;
    }

    private static int password(CommandSourceStack source, String godId) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        God god = God.byId(godId);
        player.displayClientMessage(Component.translatable("command.olympus_isles.password",
                Component.translatable(god.langKey()), Passwords.get(player.serverLevel(), god)), false);
        return 1;
    }

    private static int unclaim(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        IslandManager.Located loc = here(player);
        if (loc == null) {
            player.displayClientMessage(Component.translatable("message.olympus_isles.no_island_here"), false);
            return 0;
        }
        IslandSavedData data = IslandSavedData.get(player.serverLevel().getServer());
        IslandSavedData.Island island = IslandManager.island(player.serverLevel(), loc);
        island.owner = null;
        island.ownerName = "";
        island.trusted.clear();
        data.markDirty();
        player.displayClientMessage(Component.translatable("command.olympus_isles.unclaimed"), false);
        return 1;
    }
}
