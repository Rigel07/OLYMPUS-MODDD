package com.olympusisles.island;

import com.olympusisles.God;
import com.olympusisles.OlympusIslesMod;
import com.olympusisles.block.PasswordMonumentBlock;
import com.olympusisles.net.ModNetwork;
import com.olympusisles.net.OpenPasswordPacket;
import com.olympusisles.net.OpenTravelPacket;
import com.olympusisles.world.GodIslandStructure;
import com.olympusisles.world.GodPiece;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.TagKey;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.StructureStart;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Toda la lógica de las islas: entrar con contraseña, dueños, barrera, estatuas y viaje entre ellas. */
public final class IslandManager {
    private IslandManager() {}

    public static final TagKey<Structure> ISLANDS =
            TagKey.create(Registries.STRUCTURE, new ResourceLocation(OlympusIslesMod.MOD_ID, "god_islands"));

    /** Isla (o monumento) en la que está una posición. */
    public record Located(StructureStart start, GodIslandStructure structure, GodPiece island, GodPiece monument,
                          boolean onIsland) {
        public God god() {
            return structure.god();
        }

        public long key() {
            return start.getChunkPos().toLong();
        }
    }

    @Nullable
    public static Located locate(ServerLevel level, BlockPos pos) {
        StructureStart start = level.structureManager().getStructureWithPieceAt(pos, ISLANDS);
        if (start == null || !start.isValid() || !(start.getStructure() instanceof GodIslandStructure structure)) {
            return null;
        }
        GodPiece island = null;
        GodPiece monument = null;
        for (StructurePiece piece : start.getPieces()) {
            if (piece instanceof GodPiece godPiece) {
                if (godPiece.isIsland()) {
                    island = godPiece;
                } else {
                    monument = godPiece;
                }
            }
        }
        if (island == null || monument == null) {
            return null;
        }
        return new Located(start, structure, island, monument, island.getBoundingBox().isInside(pos));
    }

    public static IslandSavedData.Island island(ServerLevel level, Located loc) {
        return IslandSavedData.get(level.getServer()).getOrCreate(loc.key(), loc.god(),
                loc.island().getBoundingBox(), loc.monument().getBoundingBox());
    }

    private static Component godName(God god) {
        return Component.translatable(god.langKey());
    }

    private static void say(ServerPlayer player, Component message) {
        player.displayClientMessage(message, true);
    }

    // ------------------------------------------------------------------ Monumento

    public static void onMonumentUsed(ServerPlayer player, BlockPos pos, God god) {
        ServerLevel level = player.serverLevel();
        Located loc = locate(level, pos);
        if (loc == null) {
            say(player, Component.translatable("message.olympus_isles.no_island"));
            return;
        }
        IslandSavedData.Island island = island(level, loc);
        if (island.isAuthorized(player.getUUID())) {
            teleportToIsland(player, island);
            return;
        }
        if (island.owner != null) {
            say(player, Component.translatable("message.olympus_isles.owned_by", island.ownerName));
            return;
        }
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new OpenPasswordPacket(pos, god.ordinal()));
    }

    public static void onPasswordSubmitted(ServerPlayer player, BlockPos pos, String text) {
        ServerLevel level = player.serverLevel();
        if (player.distanceToSqr(Vec3.atCenterOf(pos)) > 100.0D
                || !(level.getBlockState(pos).getBlock() instanceof PasswordMonumentBlock)) {
            return;
        }
        Located loc = locate(level, pos);
        if (loc == null) {
            return;
        }
        IslandSavedData data = IslandSavedData.get(level.getServer());
        IslandSavedData.Island island = island(level, loc);
        if (!island.isAuthorized(player.getUUID()) && island.owner != null) {
            say(player, Component.translatable("message.olympus_isles.owned_by", island.ownerName));
            return;
        }
        String expected = Passwords.get(level, loc.god());
        if (!island.isAuthorized(player.getUUID()) && !expected.equalsIgnoreCase(text.trim())) {
            say(player, Component.translatable("message.olympus_isles.wrong_password"));
            level.playSound(null, pos, SoundEvents.VILLAGER_NO, SoundSource.BLOCKS, 1.0F, 0.8F);
            return;
        }
        if (island.owner == null) {
            claim(level, player, island, data);
        }
        teleportToIsland(player, island);
    }

    private static void claim(ServerLevel level, ServerPlayer player, IslandSavedData.Island island, IslandSavedData data) {
        island.owner = player.getUUID();
        island.ownerName = player.getGameProfile().getName();
        data.markDirty();
        level.getServer().getPlayerList().broadcastSystemMessage(
                Component.translatable("message.olympus_isles.claimed_broadcast", player.getDisplayName(), godName(island.god)), false);
    }

    // ------------------------------------------------------------------ Teletransporte

    public static void teleportToIsland(ServerPlayer player, IslandSavedData.Island island) {
        ServerLevel level = player.serverLevel();
        int chunkX = island.spawnX >> 4;
        int chunkZ = island.spawnZ >> 4;
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                level.getChunk(chunkX + dx, chunkZ + dz);
            }
        }
        flash(level, player);
        player.teleportTo(level, island.spawnX + 0.5D, island.spawnY, island.spawnZ + 0.5D, 180.0F, 0.0F);
        player.resetFallDistance();
        flash(level, player);
        say(player, Component.translatable("message.olympus_isles.welcome", godName(island.god)));
    }

    public static void teleportToGround(ServerPlayer player, IslandSavedData.Island island) {
        ServerLevel level = player.serverLevel();
        int chunkX = island.groundX >> 4;
        int chunkZ = island.groundZ >> 4;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                level.getChunk(chunkX + dx, chunkZ + dz);
            }
        }
        flash(level, player);
        player.teleportTo(level, island.groundX + 0.5D, island.groundY, island.groundZ + 0.5D, 0.0F, 0.0F);
        player.resetFallDistance();
    }

    private static void flash(ServerLevel level, ServerPlayer player) {
        level.sendParticles(ParticleTypes.END_ROD, player.getX(), player.getY() + 1.0D, player.getZ(),
                40, 0.5D, 0.9D, 0.5D, 0.15D);
        level.playSound(null, player.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 0.8F, 1.4F);
    }

    // ------------------------------------------------------------------ Estatua

    public static void onStatueUsed(ServerPlayer player, BlockPos pos, God god) {
        ServerLevel level = player.serverLevel();
        Located loc = locate(level, pos);
        if (loc == null) {
            return;
        }
        IslandSavedData data = IslandSavedData.get(level.getServer());
        IslandSavedData.Island island = island(level, loc);
        if (island.owner == null) {
            claim(level, player, island, data);
        }
        if (!island.isAuthorized(player.getUUID())) {
            say(player, Component.translatable("message.olympus_isles.owned_by", island.ownerName));
            return;
        }
        boolean first = data.attune(player.getUUID(), island.key);
        if (first) {
            say(player, Component.translatable("message.olympus_isles.attuned", godName(island.god)));
            level.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, player.getX(), player.getY() + 1.0D, player.getZ(),
                    40, 0.5D, 0.8D, 0.5D, 0.3D);
            level.playSound(null, pos, SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 1.0F, 1.2F);
            return;
        }
        if (!player.isShiftKeyDown()) {
            say(player, Component.translatable("message.olympus_isles.already_attuned", godName(island.god)));
            return;
        }
        List<OpenTravelPacket.Entry> entries = new ArrayList<>();
        entries.add(new OpenTravelPacket.Entry(island.key, island.god.ordinal(), island.groundX, island.groundZ, true));
        for (long key : data.attunedBy(player.getUUID())) {
            IslandSavedData.Island other = data.get(key);
            if (other != null && key != island.key && other.isAuthorized(player.getUUID())) {
                entries.add(new OpenTravelPacket.Entry(other.key, other.god.ordinal(), other.spawnX, other.spawnZ, false));
            }
        }
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new OpenTravelPacket(entries));
    }

    public static void onTravelRequested(ServerPlayer player, long key) {
        ServerLevel level = player.serverLevel();
        Located here = locate(level, player.blockPosition());
        if (here == null || !here.onIsland()) {
            return;
        }
        IslandSavedData data = IslandSavedData.get(level.getServer());
        IslandSavedData.Island current = island(level, here);
        if (!current.isAuthorized(player.getUUID())) {
            return;
        }
        if (key == current.key) {
            teleportToGround(player, current);
            return;
        }
        IslandSavedData.Island target = data.get(key);
        if (target != null && data.attunedBy(player.getUUID()).contains(key) && target.isAuthorized(player.getUUID())) {
            teleportToIsland(player, target);
        }
    }

    // ------------------------------------------------------------------ Barrera, bendición y rescate

    public static boolean isOnIsland(ServerLevel level, BlockPos pos) {
        Located loc = locate(level, pos);
        return loc != null && loc.onIsland();
    }

    private static boolean bypasses(ServerPlayer player) {
        return player.isSpectator() || (player.isCreative() && player.hasPermissions(2));
    }

    public static void tickPlayer(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        if (level.dimension() != Level.OVERWORLD || bypasses(player)) {
            return;
        }
        Located loc = locate(level, player.blockPosition());
        if (loc != null && loc.onIsland()) {
            IslandSavedData.Island island = island(level, loc);
            if (!island.isAuthorized(player.getUUID())) {
                say(player, Component.translatable("message.olympus_isles.barrier"));
                teleportToGround(player, island);
                return;
            }
            if (player.tickCount % 40 == 0) {
                for (MobEffect effect : island.god.blessing()) {
                    player.addEffect(new MobEffectInstance(effect, 140, 0, true, false, false));
                }
                player.getFoodData().setFoodLevel(20);
                purgeHostiles(level, loc.island().getBoundingBox());
            }
            return;
        }
        // Caída desde una isla: el dios te sostiene.
        if (!player.onGround() && player.fallDistance > 8.0F) {
            UUID id = player.getUUID();
            for (IslandSavedData.Island island : IslandSavedData.get(level.getServer()).all()) {
                if (island.isAuthorized(id) && island.containsXZ(player.getX(), player.getZ()) && player.getY() < island.minY) {
                    say(player, Component.translatable("message.olympus_isles.rescued"));
                    teleportToIsland(player, island);
                    return;
                }
            }
        }
    }

    private static void purgeHostiles(ServerLevel level, BoundingBox box) {
        AABB area = new AABB(box.minX(), box.minY(), box.minZ(), box.maxX() + 1, box.maxY() + 1, box.maxZ() + 1);
        for (Mob mob : level.getEntitiesOfClass(Mob.class, area, mob -> mob instanceof Enemy)) {
            level.sendParticles(ParticleTypes.POOF, mob.getX(), mob.getY() + 0.5D, mob.getZ(), 8, 0.3D, 0.3D, 0.3D, 0.02D);
            mob.discard();
        }
    }
}
