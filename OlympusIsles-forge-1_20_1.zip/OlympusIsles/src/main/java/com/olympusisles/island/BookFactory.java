package com.olympusisles.island;

import com.olympusisles.God;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** El "Libro de <dios>" que se encuentra en cofres: un poco de leyenda y la contraseña de su isla. */
public final class BookFactory {
    private BookFactory() {}

    private static String title(God god) {
        return switch (god) {
            case ZEUS -> "Libro de Zeus";
            case APHRODITE -> "Libro de Afrodita";
            case HADES -> "Libro de Hades";
            case POSEIDON -> "Libro de Poseidón";
        };
    }

    private static String legend(God god) {
        return switch (god) {
            case ZEUS -> "Zeus, hijo de Crono, venció a los Titanes y se sentó en el trono del Olimpo. "
                    + "Con el rayo que forjaron los Cíclopes gobierna el cielo y vela por la justicia.";
            case APHRODITE -> "Afrodita nació de la espuma del mar y llegó a la orilla sobre una concha. "
                    + "Diosa del amor y la belleza, hace florecer rosas allá donde pisa.";
            case HADES -> "Hades, hermano de Zeus, heredó el reino de los muertos. "
                    + "Justo e inflexible, guarda los tesoros de la tierra y su perro Cerbero vigila las puertas.";
            case POSEIDON -> "Poseidón, señor de los mares, clavó su tridente en la roca y brotaron fuentes y olas. "
                    + "Sus palacios de coral descansan bajo las aguas y su ira agita los océanos.";
        };
    }

    public static ItemStack create(ServerLevel level, God god) {
        ItemStack book = new ItemStack(Items.WRITTEN_BOOK);
        CompoundTag tag = book.getOrCreateTag();
        tag.putString("title", title(god));
        tag.putString("author", "El Oráculo de Delfos");
        tag.putInt("generation", 0);
        tag.putBoolean("resolved", true);
        ListTag pages = new ListTag();
        pages.add(StringTag.valueOf(Component.Serializer.toJson(Component.literal(title(god) + "\n\n" + legend(god)))));
        pages.add(StringTag.valueOf(Component.Serializer.toJson(Component.literal(
                "Sobre las nubes flota la isla de este dios. Bajo ella, un monumento aguarda la palabra sagrada.\n\n"
                        + "Contraseña:\n\n" + Passwords.get(level, god)))));
        tag.put("pages", pages);
        return book;
    }
}
