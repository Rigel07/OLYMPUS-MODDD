package com.olympusisles;

import com.mojang.serialization.Codec;
import com.olympusisles.block.GodStatueBlock;
import com.olympusisles.block.PasswordMonumentBlock;
import com.olympusisles.loot.AddGodBookModifier;
import com.olympusisles.world.GodIslandStructure;
import com.olympusisles.world.GodPiece;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.levelgen.structure.StructureType;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModRegistry {
    private ModRegistry() {}

    private static final String ID = OlympusIslesMod.MOD_ID;

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, ID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ID);
    public static final DeferredRegister<StructureType<?>> STRUCTURE_TYPES = DeferredRegister.create(Registries.STRUCTURE_TYPE, ID);
    public static final DeferredRegister<StructurePieceType> PIECE_TYPES = DeferredRegister.create(Registries.STRUCTURE_PIECE, ID);
    public static final DeferredRegister<Codec<? extends IGlobalLootModifier>> LOOT_MODIFIERS =
            DeferredRegister.create(ForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS, ID);

    // ---- Bloques interactivos (inamovibles en supervivencia) ----
    public static final RegistryObject<Block> GOD_STATUE = BLOCKS.register("god_statue",
            () -> new GodStatueBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.QUARTZ)
                    .strength(-1.0F, 3600000.0F)
                    .sound(SoundType.STONE)));
    public static final RegistryObject<Block> PASSWORD_MONUMENT = BLOCKS.register("password_monument",
            () -> new PasswordMonumentBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.GOLD)
                    .strength(-1.0F, 3600000.0F)
                    .sound(SoundType.STONE)
                    .lightLevel(state -> 9)));

    public static final RegistryObject<Item> GOD_STATUE_ITEM = ITEMS.register("god_statue",
            () -> new BlockItem(GOD_STATUE.get(), new Item.Properties().rarity(Rarity.EPIC)));
    public static final RegistryObject<Item> PASSWORD_MONUMENT_ITEM = ITEMS.register("password_monument",
            () -> new BlockItem(PASSWORD_MONUMENT.get(), new Item.Properties().rarity(Rarity.EPIC)));

    // ---- Estructuras ----
    public static final RegistryObject<StructureType<GodIslandStructure>> GOD_ISLAND =
            STRUCTURE_TYPES.register("god_island", ModRegistry::godIslandType);
    public static final RegistryObject<StructurePieceType> GOD_PIECE =
            PIECE_TYPES.register("god_piece", ModRegistry::godPieceType);

    private static StructureType<GodIslandStructure> godIslandType() {
        return () -> GodIslandStructure.CODEC;
    }

    private static StructurePieceType godPieceType() {
        return (context, tag) -> new GodPiece(context.structureTemplateManager(), tag);
    }

    // ---- Libros en cofres (modificador global de botín) ----
    public static final RegistryObject<Codec<? extends IGlobalLootModifier>> ADD_GOD_BOOK =
            LOOT_MODIFIERS.register("add_god_book", AddGodBookModifier.CODEC);

    // ---- Pestaña creativa ----
    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("olympus_isles_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.olympus_isles"))
                    .icon(() -> new ItemStack(GOD_STATUE_ITEM.get()))
                    .displayItems((params, output) -> {
                        output.accept(GOD_STATUE_ITEM.get());
                        output.accept(PASSWORD_MONUMENT_ITEM.get());
                    })
                    .build());

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
        STRUCTURE_TYPES.register(bus);
        PIECE_TYPES.register(bus);
        LOOT_MODIFIERS.register(bus);
    }
}
