package com.olympusisles;

import net.minecraft.util.StringRepresentable;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffects;

import java.util.Locale;

/** Los dioses con isla. Para añadir uno nuevo: un valor aquí, su plantilla .nbt, su estructura y su libro. */
public enum God implements StringRepresentable {
    ZEUS("zeus", new String[]{"KERAUNOS", "OLIMPO", "AEGIS", "TRUENO"},
            new MobEffect[]{MobEffects.MOVEMENT_SPEED, MobEffects.DIG_SPEED}),
    APHRODITE("aphrodite", new String[]{"CITEREA", "PAFOS", "ROSA", "PALOMA"},
            new MobEffect[]{MobEffects.LUCK, MobEffects.JUMP}),
    HADES("hades", new String[]{"ERIBO", "TARTARO", "ESTIGIA", "ASFODELO"},
            new MobEffect[]{MobEffects.FIRE_RESISTANCE, MobEffects.NIGHT_VISION, MobEffects.DAMAGE_BOOST}),
    POSEIDON("poseidon", new String[]{"TRIDENTE", "ATLANTIDA", "NEREIDA", "ABISMO"},
            new MobEffect[]{MobEffects.WATER_BREATHING, MobEffects.DOLPHINS_GRACE, MobEffects.CONDUIT_POWER});

    private final String id;
    private final String[] words;
    private final MobEffect[] blessing;

    God(String id, String[] words, MobEffect[] blessing) {
        this.id = id;
        this.words = words;
        this.blessing = blessing;
    }

    @Override
    public String getSerializedName() {
        return id;
    }

    public String[] words() {
        return words;
    }

    /** Efectos de la bendición de la isla. */
    public MobEffect[] blessing() {
        return blessing;
    }

    public String langKey() {
        return "god.olympus_isles." + id;
    }

    public static God byId(String id) {
        String lower = id == null ? "" : id.toLowerCase(Locale.ROOT);
        for (God god : values()) {
            if (god.id.equals(lower)) {
                return god;
            }
        }
        return ZEUS;
    }

    public static God byOrdinal(int ordinal) {
        God[] all = values();
        return all[Math.floorMod(ordinal, all.length)];
    }
}
