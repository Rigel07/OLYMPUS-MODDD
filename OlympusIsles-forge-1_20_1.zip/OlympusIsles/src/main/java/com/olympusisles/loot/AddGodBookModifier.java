package com.olympusisles.loot;

import com.google.common.base.Suppliers;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.olympusisles.God;
import com.olympusisles.island.BookFactory;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.common.loot.LootModifier;

import java.util.function.Supplier;

/** Añade, con cierta probabilidad, el "Libro de <dios>" (con su contraseña) a los cofres que se indiquen. */
public class AddGodBookModifier extends LootModifier {
    public static final Supplier<Codec<AddGodBookModifier>> CODEC = Suppliers.memoize(() ->
            RecordCodecBuilder.create(inst -> codecStart(inst)
                    .and(Codec.STRING.fieldOf("god").forGetter(modifier -> modifier.god))
                    .and(Codec.FLOAT.fieldOf("chance").forGetter(modifier -> modifier.chance))
                    .apply(inst, AddGodBookModifier::new)));

    private final String god;
    private final float chance;

    public AddGodBookModifier(LootItemCondition[] conditions, String god, float chance) {
        super(conditions);
        this.god = god;
        this.chance = chance;
    }

    @Override
    protected ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> generatedLoot, LootContext context) {
        if (context.getRandom().nextFloat() < chance) {
            generatedLoot.add(BookFactory.create(context.getLevel(), God.byId(god)));
        }
        return generatedLoot;
    }

    @Override
    public Codec<? extends IGlobalLootModifier> codec() {
        return CODEC.get();
    }
}
