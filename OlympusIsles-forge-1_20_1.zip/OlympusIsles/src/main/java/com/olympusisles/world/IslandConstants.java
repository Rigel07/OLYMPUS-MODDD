package com.olympusisles.world;

/**
 * Medidas compartidas con el generador de plantillas (tools/). Si cambias algo aquí, cámbialo también allí.
 */
public final class IslandConstants {
    private IslandConstants() {}

    /** Plantilla de la isla: ancho, alto y fondo. */
    public static final int ISLAND_SX = 125;
    public static final int ISLAND_SY = 112;
    public static final int ISLAND_SZ = 125;
    /** Altura del mundo a la que empieza la plantilla de la isla (la superficie queda a ISLAND_Y + 48). */
    public static final int ISLAND_Y = 168;
    /** Donde aparece el jugador al llegar (relativo a la esquina mínima de la plantilla): delante de la estatua. */
    public static final int SPAWN_X = 62;
    public static final int SPAWN_Y = 49;
    public static final int SPAWN_Z = 78;

    /** Plantilla del monumento del suelo. */
    public static final int MON_SX = 13;
    public static final int MON_SY = 16;
    public static final int MON_SZ = 13;
    /** Capa de la plantilla que queda a ras del terreno (el suelo del monumento). */
    public static final int MON_FLOOR = 3;
    /** Donde aparece el jugador al bajar al suelo: delante del monumento. */
    public static final int MON_SPAWN_X = 6;
    public static final int MON_SPAWN_Y = 4;
    public static final int MON_SPAWN_Z = 11;

    /** Terreno máximo (y) sobre el que se genera un monumento, para que la isla quede siempre por encima. */
    public static final int MAX_GROUND = 125;
}
