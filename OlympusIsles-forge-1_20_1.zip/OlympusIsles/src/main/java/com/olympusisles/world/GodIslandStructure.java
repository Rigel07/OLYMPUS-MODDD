package com.olympusisles.world;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.olympusisles.God;
import com.olympusisles.ModRegistry;
import com.olympusisles.OlympusIslesMod;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplateManager;

import java.util.Optional;

/**
 * La estructura de un dios: una isla enorme flotando en lo alto y, justo debajo, sobre el terreno,
 * el monumento donde se escribe la contraseña. Se declara en data/olympus_isles/worldgen/structure/.
 */
public class GodIslandStructure extends Structure {
    public static final Codec<GodIslandStructure> CODEC = RecordCodecBuilder.<GodIslandStructure>mapCodec(instance ->
            instance.group(settingsCodec(instance),
                            Codec.STRING.fieldOf("god").forGetter(structure -> structure.god.getSerializedName()))
                    .apply(instance, (settings, id) -> new GodIslandStructure(settings, God.byId(id)))).codec();

    private final God god;

    protected GodIslandStructure(StructureSettings settings, God god) {
        super(settings);
        this.god = god;
    }

    public God god() {
        return god;
    }

    @Override
    public StructureType<?> type() {
        return ModRegistry.GOD_ISLAND.get();
    }

    @Override
    protected Optional<GenerationStub> findGenerationPoint(GenerationContext context) {
        ChunkPos chunkPos = context.chunkPos();
        int cx = chunkPos.getMiddleBlockX();
        int cz = chunkPos.getMiddleBlockZ();
        int ground = context.chunkGenerator().getFirstFreeHeight(cx, cz, Heightmap.Types.WORLD_SURFACE_WG,
                context.heightAccessor(), context.randomState());
        if (ground > IslandConstants.MAX_GROUND) {
            return Optional.empty();
        }
        NoiseColumn column = context.chunkGenerator().getBaseColumn(cx, cz, context.heightAccessor(), context.randomState());
        if (!column.getBlock(ground - 1).getFluidState().isEmpty()) {
            return Optional.empty();
        }

        ResourceLocation islandId = new ResourceLocation(OlympusIslesMod.MOD_ID, god.getSerializedName() + "_island");
        ResourceLocation monumentId = new ResourceLocation(OlympusIslesMod.MOD_ID, god.getSerializedName() + "_monument");
        BlockPos islandPos = new BlockPos(cx - IslandConstants.ISLAND_SX / 2, IslandConstants.ISLAND_Y,
                cz - IslandConstants.ISLAND_SZ / 2);
        BlockPos monumentPos = new BlockPos(cx - IslandConstants.MON_SX / 2, ground - 1 - IslandConstants.MON_FLOOR,
                cz - IslandConstants.MON_SZ / 2);
        StructureTemplateManager manager = context.structureTemplateManager();

        return Optional.of(new GenerationStub(new BlockPos(cx, ground, cz), builder -> {
            builder.addPiece(new GodPiece(manager, islandId, islandPos, true));
            builder.addPiece(new GodPiece(manager, monumentId, monumentPos, false));
        }));
    }
}
