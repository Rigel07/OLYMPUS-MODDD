package com.olympusisles.client;

import com.olympusisles.God;
import com.olympusisles.net.ModNetwork;
import com.olympusisles.net.OpenTravelPacket;
import com.olympusisles.net.TravelPacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

/** Pantalla de viaje entre estatuas sintonizadas (y bajada al monumento del suelo). */
public class TravelScreen extends Screen {
    private final List<OpenTravelPacket.Entry> entries;

    public TravelScreen(List<OpenTravelPacket.Entry> entries) {
        super(Component.translatable("gui.olympus_isles.travel_title"));
        this.entries = entries;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int top = this.height / 2 - (entries.size() * 24) / 2;
        for (int i = 0; i < entries.size(); i++) {
            OpenTravelPacket.Entry entry = entries.get(i);
            Component god = Component.translatable(God.byOrdinal(entry.god()).langKey());
            Component label = entry.ground()
                    ? Component.translatable("gui.olympus_isles.travel_ground", entry.x(), entry.z())
                    : Component.translatable("gui.olympus_isles.travel_entry", god, entry.x(), entry.z());
            this.addRenderableWidget(Button.builder(label, button -> {
                ModNetwork.CHANNEL.sendToServer(new TravelPacket(entry.key()));
                onClose();
            }).bounds(cx - 120, top + i * 24, 240, 20).build());
        }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        graphics.drawCenteredString(this.font, this.title, this.width / 2,
                this.height / 2 - (entries.size() * 24) / 2 - 20, 0xFFD966);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
