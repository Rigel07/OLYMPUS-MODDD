package com.olympusisles.client;

import com.olympusisles.God;
import com.olympusisles.net.OpenTravelPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

import java.util.List;

/** Puente servidor -> pantallas del cliente (solo se carga en el cliente). */
public final class ClientHooks {
    private ClientHooks() {}

    public static void openPassword(BlockPos pos, int god) {
        Minecraft.getInstance().setScreen(new PasswordScreen(pos, God.byOrdinal(god)));
    }

    public static void openTravel(List<OpenTravelPacket.Entry> entries) {
        Minecraft.getInstance().setScreen(new TravelScreen(entries));
    }
}
