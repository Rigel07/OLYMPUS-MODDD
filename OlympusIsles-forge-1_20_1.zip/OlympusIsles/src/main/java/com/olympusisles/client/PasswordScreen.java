package com.olympusisles.client;

import com.olympusisles.God;
import com.olympusisles.net.ModNetwork;
import com.olympusisles.net.PasswordPacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

/** Pantalla del monumento: aquí se escribe la contraseña del libro del dios. */
public class PasswordScreen extends Screen {
    private final BlockPos pos;
    private final God god;
    private EditBox input;

    public PasswordScreen(BlockPos pos, God god) {
        super(Component.translatable("gui.olympus_isles.password_title", Component.translatable(god.langKey())));
        this.pos = pos;
        this.god = god;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int cy = this.height / 2;
        this.input = new EditBox(this.font, cx - 100, cy - 10, 200, 20, Component.empty());
        this.input.setMaxLength(48);
        this.addRenderableWidget(this.input);
        this.setInitialFocus(this.input);
        this.addRenderableWidget(Button.builder(Component.translatable("gui.olympus_isles.confirm"), button -> submit())
                .bounds(cx - 100, cy + 20, 98, 20).build());
        this.addRenderableWidget(Button.builder(Component.translatable("gui.olympus_isles.cancel"), button -> onClose())
                .bounds(cx + 2, cy + 20, 98, 20).build());
    }

    private void submit() {
        ModNetwork.CHANNEL.sendToServer(new PasswordPacket(pos, input.getValue()));
        onClose();
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 257 || keyCode == 335) {
            submit();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        graphics.drawCenteredString(this.font, this.title, this.width / 2, this.height / 2 - 44, 0xFFD966);
        graphics.drawCenteredString(this.font, Component.translatable("gui.olympus_isles.password_hint"),
                this.width / 2, this.height / 2 - 30, 0xB0B0B0);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
