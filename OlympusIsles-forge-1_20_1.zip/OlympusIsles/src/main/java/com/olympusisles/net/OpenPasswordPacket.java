package com.olympusisles.net;

import com.olympusisles.client.ClientHooks;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Servidor -> cliente: abre la pantalla de la contraseña del monumento. */
public class OpenPasswordPacket {
    private final BlockPos pos;
    private final int god;

    public OpenPasswordPacket(BlockPos pos, int god) {
        this.pos = pos;
        this.god = god;
    }

    public static void encode(OpenPasswordPacket packet, FriendlyByteBuf buf) {
        buf.writeBlockPos(packet.pos);
        buf.writeVarInt(packet.god);
    }

    public static OpenPasswordPacket decode(FriendlyByteBuf buf) {
        return new OpenPasswordPacket(buf.readBlockPos(), buf.readVarInt());
    }

    public static void handle(OpenPasswordPacket packet, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientHooks.openPassword(packet.pos, packet.god)));
        context.setPacketHandled(true);
    }
}
