package com.olympusisles.net;

import com.olympusisles.client.ClientHooks;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** Servidor -> cliente: lista de destinos del viaje entre estatuas. */
public class OpenTravelPacket {
    /** Un destino: una isla sintonizada (o el suelo bajo la isla actual). */
    public record Entry(long key, int god, int x, int z, boolean ground) {}

    private final List<Entry> entries;

    public OpenTravelPacket(List<Entry> entries) {
        this.entries = entries;
    }

    public static void encode(OpenTravelPacket packet, FriendlyByteBuf buf) {
        buf.writeVarInt(packet.entries.size());
        for (Entry entry : packet.entries) {
            buf.writeLong(entry.key());
            buf.writeVarInt(entry.god());
            buf.writeInt(entry.x());
            buf.writeInt(entry.z());
            buf.writeBoolean(entry.ground());
        }
    }

    public static OpenTravelPacket decode(FriendlyByteBuf buf) {
        int size = buf.readVarInt();
        List<Entry> entries = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            entries.add(new Entry(buf.readLong(), buf.readVarInt(), buf.readInt(), buf.readInt(), buf.readBoolean()));
        }
        return new OpenTravelPacket(entries);
    }

    public static void handle(OpenTravelPacket packet, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientHooks.openTravel(packet.entries)));
        context.setPacketHandled(true);
    }
}
