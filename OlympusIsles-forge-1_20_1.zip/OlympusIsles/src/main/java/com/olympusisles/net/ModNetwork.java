package com.olympusisles.net;

import com.olympusisles.OlympusIslesMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private ModNetwork() {}

    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(OlympusIslesMod.MOD_ID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, OpenPasswordPacket.class, OpenPasswordPacket::encode, OpenPasswordPacket::decode,
                OpenPasswordPacket::handle);
        CHANNEL.registerMessage(id++, PasswordPacket.class, PasswordPacket::encode, PasswordPacket::decode,
                PasswordPacket::handle);
        CHANNEL.registerMessage(id++, OpenTravelPacket.class, OpenTravelPacket::encode, OpenTravelPacket::decode,
                OpenTravelPacket::handle);
        CHANNEL.registerMessage(id++, TravelPacket.class, TravelPacket::encode, TravelPacket::decode,
                TravelPacket::handle);
    }
}
