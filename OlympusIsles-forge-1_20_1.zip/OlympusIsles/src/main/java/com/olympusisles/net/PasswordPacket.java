package com.olympusisles.net;

import com.olympusisles.island.IslandManager;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Cliente -> servidor: la contraseña escrita en el monumento. */
public class PasswordPacket {
    private final BlockPos pos;
    private final String text;

    public PasswordPacket(BlockPos pos, String text) {
        this.pos = pos;
        this.text = text;
    }

    public static void encode(PasswordPacket packet, FriendlyByteBuf buf) {
        buf.writeBlockPos(packet.pos);
        buf.writeUtf(packet.text, 64);
    }

    public static PasswordPacket decode(FriendlyByteBuf buf) {
        return new PasswordPacket(buf.readBlockPos(), buf.readUtf(64));
    }

    public static void handle(PasswordPacket packet, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player != null) {
                IslandManager.onPasswordSubmitted(player, packet.pos, packet.text);
            }
        });
        context.setPacketHandled(true);
    }
}
