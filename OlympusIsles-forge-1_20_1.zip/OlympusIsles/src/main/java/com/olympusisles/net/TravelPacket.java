package com.olympusisles.net;

import com.olympusisles.island.IslandManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Cliente -> servidor: destino elegido en la pantalla de viaje. */
public class TravelPacket {
    private final long key;

    public TravelPacket(long key) {
        this.key = key;
    }

    public static void encode(TravelPacket packet, FriendlyByteBuf buf) {
        buf.writeLong(packet.key);
    }

    public static TravelPacket decode(FriendlyByteBuf buf) {
        return new TravelPacket(buf.readLong());
    }

    public static void handle(TravelPacket packet, Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player != null) {
                IslandManager.onTravelRequested(player, packet.key);
            }
        });
        context.setPacketHandled(true);
    }
}
