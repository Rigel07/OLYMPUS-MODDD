import gzip, struct, math, os, contextlib

# ============================================================ NBT
class T:
    def __init__(self, t, v):
        self.t = t
        self.v = v

def Byte(v): return T(1, v)
def Int(v): return T(3, v)
def Double(v): return T(6, v)
def String(v): return T(8, v)
def List(et, items): return T(9, (et, items))
def Compound(d): return T(10, d)

def _payload(t, v, out):
    if t == 1:
        out += struct.pack(">b", v)
    elif t == 3:
        out += struct.pack(">i", v)
    elif t == 6:
        out += struct.pack(">d", v)
    elif t == 8:
        b = v.encode("utf-8")
        out += struct.pack(">H", len(b)) + b
    elif t == 9:
        et, items = v
        out += struct.pack(">b", et) + struct.pack(">i", len(items))
        for it in items:
            _payload(et, it, out)
    elif t == 10:
        for k, tag in v.items():
            out += struct.pack(">b", tag.t)
            kb = k.encode("utf-8")
            out += struct.pack(">H", len(kb)) + kb
            _payload(tag.t, tag.v, out)
        out += b"\x00"
    else:
        raise ValueError(t)

def write_nbt(path, root):
    out = bytearray()
    out += struct.pack(">b", 10) + struct.pack(">H", 0)
    _payload(10, root, out)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with gzip.GzipFile(path, "wb", compresslevel=9, mtime=0) as f:
        f.write(bytes(out))

def full(name):
    return name if ":" in name else "minecraft:" + name

def book_item(slot, title, pages, author="El Oráculo de Delfos"):
    import json
    page_tags = [json.dumps({"text": p}, ensure_ascii=False) for p in pages]
    return {"Slot": Byte(slot), "id": String("minecraft:written_book"), "Count": Byte(1),
            "tag": Compound({"title": String(title), "author": String(author), "generation": Int(0),
                             "resolved": Byte(1), "pages": List(8, page_tags)})}

# ============================================================ Lienzo
FACINGS = ["north", "east", "south", "west"]

class Canvas:
    def __init__(self, sx, sy, sz):
        self.size = (sx, sy, sz)
        self.palette = []
        self.index = {}
        self.blocks = {}      # (x,y,z) -> índice de paleta
        self.nbt = {}         # (x,y,z) -> Compound
        self.skipped = 0
        self.ox = self.oy = self.oz = 0
        self.rot = 0

    # ---- transformación local -> mundo
    @contextlib.contextmanager
    def at(self, ox, oy, oz, rot=0):
        saved = (self.ox, self.oy, self.oz, self.rot)
        self.ox, self.oy, self.oz, self.rot = ox, oy, oz, rot
        try:
            yield self
        finally:
            self.ox, self.oy, self.oz, self.rot = saved

    def world(self, lx, ly, lz):
        r = self.rot % 4
        if r == 0:
            x, z = lx, lz
        elif r == 1:
            x, z = -lz, lx
        elif r == 2:
            x, z = -lx, -lz
        else:
            x, z = lz, -lx
        return self.ox + x, self.oy + ly, self.oz + z

    def _rotate_props(self, props):
        if not props:
            return {}
        out = dict(props)
        r = self.rot % 4
        if r and "facing" in out and out["facing"] in FACINGS:
            out["facing"] = FACINGS[(FACINGS.index(out["facing"]) + r) % 4]
        if r % 2 == 1 and "axis" in out and out["axis"] in ("x", "z"):
            out["axis"] = "z" if out["axis"] == "x" else "x"
        return out

    def _idx(self, name, props):
        key = (full(name), tuple(sorted((k, (str(v).lower() if isinstance(v, bool) else str(v))) for k, v in props.items())))
        i = self.index.get(key)
        if i is None:
            i = len(self.palette)
            self.index[key] = i
            self.palette.append(key)
        return i

    # ---- escritura en coordenadas de mundo (sin transformar)
    def put_w(self, x, y, z, name, props=None, nbt=None):
        sx, sy, sz = self.size
        if not (0 <= x < sx and 0 <= y < sy and 0 <= z < sz):
            self.skipped += 1
            return
        self.blocks[(x, y, z)] = self._idx(name, props or {})
        if nbt is not None:
            self.nbt[(x, y, z)] = nbt
        elif (x, y, z) in self.nbt:
            del self.nbt[(x, y, z)]

    def remove_w(self, x, y, z):
        self.blocks.pop((x, y, z), None)
        self.nbt.pop((x, y, z), None)

    def name_at_w(self, x, y, z):
        i = self.blocks.get((x, y, z))
        return None if i is None else self.palette[i][0]

    # ---- escritura local (con rotación)
    def put(self, lx, ly, lz, name, props=None, nbt=None):
        x, y, z = self.world(lx, ly, lz)
        self.put_w(x, y, z, name, self._rotate_props(props), nbt)

    def fill(self, x1, y1, z1, x2, y2, z2, name, props=None):
        for x in range(min(x1, x2), max(x1, x2) + 1):
            for y in range(min(y1, y2), max(y1, y2) + 1):
                for z in range(min(z1, z2), max(z1, z2) + 1):
                    self.put(x, y, z, name, props)

    def walls(self, x1, z1, x2, z2, y1, y2, name, props=None):
        for y in range(y1, y2 + 1):
            for x in range(x1, x2 + 1):
                self.put(x, y, z1, name, props); self.put(x, y, z2, name, props)
            for z in range(z1, z2 + 1):
                self.put(x1, y, z, name, props); self.put(x2, y, z, name, props)

    def clear(self, x1, y1, z1, x2, y2, z2):
        for x in range(min(x1, x2), max(x1, x2) + 1):
            for y in range(min(y1, y2), max(y1, y2) + 1):
                for z in range(min(z1, z2), max(z1, z2) + 1):
                    wx, wy, wz = self.world(x, y, z)
                    self.remove_w(wx, wy, wz)

    def stairs(self, lx, ly, lz, name, facing, half="bottom"):
        self.put(lx, ly, lz, name, {"facing": facing, "half": half, "shape": "straight", "waterlogged": "false"})

    def slab(self, lx, ly, lz, name, typ="bottom"):
        self.put(lx, ly, lz, name, {"type": typ, "waterlogged": "false"})

    def pillar(self, lx, ly, lz, name, axis="y"):
        self.put(lx, ly, lz, name, {"axis": axis})

    def chest(self, lx, ly, lz, facing, loot=None, items=None):
        nbt = {"id": String("minecraft:chest")}
        if loot:
            nbt["LootTable"] = String(loot)
        if items:
            nbt["Items"] = List(10, items)
        self.put(lx, ly, lz, "chest", {"facing": facing, "type": "single", "waterlogged": False}, Compound(nbt))

    def barrel(self, lx, ly, lz, facing, loot):
        self.put(lx, ly, lz, "barrel", {"facing": facing, "open": False},
                 Compound({"id": String("minecraft:barrel"), "LootTable": String(loot)}))

    def lantern(self, lx, ly, lz, hanging=False, name="lantern"):
        self.put(lx, ly, lz, name, {"hanging": hanging, "waterlogged": False})

    def leaves(self, lx, ly, lz, name):
        self.put(lx, ly, lz, name, {"distance": 1, "persistent": True, "waterlogged": False})

    def top_y(self, x, z, below=None):
        """Altura (mundo) del bloque más alto de una columna."""
        sx, sy, sz = self.size
        start = sy - 1 if below is None else below
        for y in range(start, -1, -1):
            if (x, y, z) in self.blocks:
                return y
        return -1

    # ---- guardado
    def save(self, path):
        blocks = []
        for (x, y, z), i in sorted(self.blocks.items(), key=lambda kv: (kv[0][1], kv[0][0], kv[0][2])):
            b = {"pos": List(3, [x, y, z]), "state": Int(i)}
            nbt = self.nbt.get((x, y, z))
            if nbt is not None:
                b["nbt"] = nbt
            blocks.append(b)
        palette = []
        for name, props in self.palette:
            entry = {"Name": String(name)}
            if props:
                entry["Properties"] = Compound({k: String(v) for k, v in props})
            palette.append(entry)
        root = {"size": List(3, list(self.size)), "entities": List(10, []),
                "blocks": List(10, blocks), "palette": List(10, palette), "DataVersion": Int(3465)}
        write_nbt(path, root)
        return len(blocks), len(palette)

# ============================================================ Formas
def disc(cx, cz, r):
    ri = int(math.ceil(r))
    return [(x, z) for x in range(cx - ri, cx + ri + 1) for z in range(cz - ri, cz + ri + 1)
            if math.hypot(x - cx, z - cz) <= r]

def ring(cx, cz, r_in, r_out):
    ri = int(math.ceil(r_out))
    return [(x, z) for x in range(cx - ri, cx + ri + 1) for z in range(cz - ri, cz + ri + 1)
            if r_in < math.hypot(x - cx, z - cz) <= r_out]

def nearest_facing(dx, dz):
    if abs(dx) >= abs(dz):
        return "east" if dx > 0 else "west"
    return "south" if dz > 0 else "north"

# ============================================================ Ruido determinista
def _h(ix, iz, seed):
    n = (ix * 374761393 + iz * 668265263 + seed * 1442695041) & 0xFFFFFFFF
    n = ((n ^ (n >> 13)) * 1274126177) & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 65535.0

def vnoise(x, z, scale, seed):
    fx, fz = x / scale, z / scale
    ix, iz = math.floor(fx), math.floor(fz)
    tx, tz = fx - ix, fz - iz
    tx, tz = tx * tx * (3 - 2 * tx), tz * tz * (3 - 2 * tz)
    a, b = _h(ix, iz, seed), _h(ix + 1, iz, seed)
    c, d = _h(ix, iz + 1, seed), _h(ix + 1, iz + 1, seed)
    return (a * (1 - tx) + b * tx) * (1 - tz) + (c * (1 - tx) + d * tx) * tz

def fbm(x, z, seed):
    return 0.6 * vnoise(x, z, 14.0, seed) + 0.3 * vnoise(x, z, 6.0, seed + 7) + 0.1 * vnoise(x, z, 3.0, seed + 13)

def chance(x, y, z, seed, p):
    return _h(x * 7 + y * 13, z * 11 + y * 3, seed) < p

# ============================================================ Vistas rápidas
def preview_top(c, path, colors, scale=5):
    from PIL import Image
    sx, sy, sz = c.size
    img = Image.new("RGB", (sx * scale, sz * scale), (150, 195, 235))
    px = img.load()
    for x in range(sx):
        for z in range(sz):
            y = c.top_y(x, z)
            if y < 0:
                continue
            name = c.name_at_w(x, y, z).split(":")[1]
            col = (190, 190, 190)
            for key, rgb in colors:
                if key in name:
                    col = rgb
                    break
            shade = 0.75 + 0.25 * min(1.0, y / 100.0)
            col = tuple(int(v * shade) for v in col)
            for dx in range(scale):
                for dz in range(scale):
                    px[x * scale + dx, z * scale + dz] = col
    img.save(path)

def preview_side(c, path, colors, scale=5):
    from PIL import Image
    sx, sy, sz = c.size
    img = Image.new("RGB", (sx * scale, sy * scale), (150, 195, 235))
    px = img.load()
    depth = {}
    for (x, y, z), i in c.blocks.items():
        k = (x, y)
        if k not in depth or z < depth[k][0]:
            depth[k] = (z, i)
    for (x, y), (z, i) in depth.items():
        name = c.palette[i][0].split(":")[1]
        col = (190, 190, 190)
        for key, rgb in colors:
            if key in name:
                col = rgb
                break
        for dx in range(scale):
            for dy in range(scale):
                px[x * scale + dx, (sy - 1 - y) * scale + dy] = col
    img.save(path)
