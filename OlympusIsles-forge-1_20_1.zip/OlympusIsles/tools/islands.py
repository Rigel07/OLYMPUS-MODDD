import math, random
from lib import *
from lib import _h
from designs import *

# =====================================================================================
#  TEXTOS: la leyenda de cada dios (libro del cofre de la isla)
# =====================================================================================
LORE = {
    "zeus": ("La leyenda de Zeus", [
        "ZEUS, REY DEL OLIMPO\n\nHijo de Crono y Rea, Zeus se alzó contra los Titanes y los venció tras diez años de guerra.",
        "Al repartirse el mundo con sus hermanos, a Zeus le tocó el cielo. Desde el Olimpo lanza el rayo que forjaron los Cíclopes.",
        "Protege la justicia y la hospitalidad. Cuentan que su águila recorre el mundo para contarle cada promesa rota."]),
    "aphrodite": ("La leyenda de Afrodita", [
        "AFRODITA, DIOSA DEL AMOR\n\nNació de la espuma del mar, cerca de Chipre, y llegó a la orilla sobre una concha de nácar.",
        "Allá donde pisa brotan rosas y las palomas la acompañan. Su cinturón encantado despierta el amor en dioses y mortales.",
        "Se enamoró de la belleza del mundo entero. Por eso su isla es un jardín que nunca se marchita."]),
    "hades": ("La leyenda de Hades", [
        "HADES, SEÑOR DEL INFRAMUNDO\n\nHermano de Zeus y de Poseidón, recibió en el reparto el reino de los muertos.",
        "Gobierna bajo la tierra junto a Perséfone. Cerbero, su perro de tres cabezas, vigila las puertas del Tártaro.",
        "No es cruel, sino justo e inflexible. Guarda todas las riquezas de la tierra y nunca devuelve lo que se le confía."]),
    "poseidon": ("La leyenda de Poseidón", [
        "POSEIDÓN, SEÑOR DE LOS MARES\n\nHermano de Zeus, recibió el dominio de las aguas, de los terremotos y de los caballos.",
        "Clavó su tridente en una roca y brotaron fuentes y olas. Sus palacios de coral y perlas descansan bajo el océano.",
        "Su ira agita las tormentas, pero su favor llena las redes de los pescadores y guía a los barcos de vuelta a casa."]),
}

def story_book(god, slot=13):
    title, pages = LORE[god]
    return book_item(slot, title, pages)

def ensure_spawn(c, floor):
    """El punto de llegada (62, 49, 78) debe ser suelo firme con aire encima."""
    for dx in (-1, 0, 1):
        for dz in (-1, 0, 1):
            for y in range(SURF + 1, SURF + 5):
                c.remove_w(62 + dx, y, 78 + dz)
            c.put_w(62 + dx, SURF, 78 + dz, floor)

def free_circle(rnd, occupied, rmin, rmax, margin=2, tries=40):
    for _ in range(tries):
        a = rnd.uniform(0, 2 * math.pi)
        r = rnd.uniform(rmin, rmax)
        x, z = int(CX + math.cos(a) * r), int(CZ + math.sin(a) * r)
        if 0 <= x < SX and 0 <= z < SZ and keep_free(occupied, x, z, margin) and (x, SURF, z) in c_ref[0].blocks:
            return x, z
    return None

c_ref = [None]

# =====================================================================================
#  ZEUS
# =====================================================================================
def build_zeus():
    c = Canvas(SX, SY, SZ)
    c_ref[0] = c
    rnd = random.Random(1001)
    M = ZEUS_M
    cfg = dict(seed=11, p1=0.4, p2=1.7, depth=44,
               top=lambda x, z, t: "grass_block",
               sub=lambda x, z, t: "dirt",
               stone=lambda x, y, z: "stone" if _h(x, y * 3 + z, 31) > 0.2 else ("andesite" if _h(x, y, z + 9) > 0.5 else "calcite"),
               bottom=lambda x, y, z: "calcite" if _h(x, y, z) > 0.4 else "tuff")
    build_island(c, cfg)
    occupied = [(CX, CZ, 25), (CX, 26, 19), (96, 62, 13), (32, 62, 19), (38, 92, 11), (CX, 98, 8)]

    # plaza circular de mármol
    for (x, z) in disc(CX, CZ, 21):
        r = math.hypot(x - CX, z - CZ)
        if r <= 10:
            n = "smooth_quartz"
        elif r <= 11.2:
            n = "chiseled_quartz_block"
        elif r > 19.8:
            n = "quartz_bricks"
        else:
            n = "smooth_quartz" if (x + z) % 2 == 0 else "quartz_block"
        c.put_w(x, SURF, z, n)
    for (dx, dz) in ((15, 0), (-15, 0), (0, 15), (0, -15)):
        for ax in (0, 1):
            for az in (0, 1):
                c.put_w(CX + dx + ax, SURF, CZ + dz + az, "gold_block")
    with c.at(CX, SURF + 1, CZ, 0):
        colossus(c, M, "zeus")
    for (dx, dz) in ((13, 13), (-13, 13), (13, -13), (-13, -13)):
        with c.at(CX + dx, SURF + 1, CZ + dz, 0):
            brazier(c, 0, 0, 0, M)

    # avenida procesional hacia el sur con columnas y pararrayos
    flatten(c, [(x, z) for x in range(CX - 9, CX + 10) for z in range(CZ + 20, CZ + 56)])
    for z in range(CZ + 21, CZ + 52):
        for x in range(CX - 3, CX + 4):
            c.put_w(x, SURF, z, "smooth_quartz" if abs(x - CX) <= 2 else "quartz_bricks")
    for z in (CZ + 27, CZ + 35, CZ + 43):
        for sx in (-6, 6):
            for dy in range(1, 7):
                c.pillar(CX + sx - CX, 0, 0, "quartz_pillar") if False else c.put_w(CX + sx, SURF + dy, z, "quartz_pillar", {"axis": "y"})
            c.put_w(CX + sx, SURF + 7, z, "chiseled_quartz_block")
            c.put_w(CX + sx, SURF + 8, z, "lightning_rod", {"facing": "up", "powered": False, "waterlogged": False})
    with c.at(CX, SURF + 1, CZ + 50, 0):
        gate(c, M, 9, 10)

    # templo de Zeus al norte (fachada hacia la plaza)
    flatten(c, [(x, z) for x in range(CX - 14, CX + 15) for z in range(10, 44)])
    with c.at(CX + 10, SURF + 1, 40, 2):
        info = temple(c, M, 21, 27, 9)
        c.chest(10, 3, 19, "north", items=[story_book("zeus")])
        c.chest(8, 3, 19, "north", loot="olympus_isles:chests/zeus_treasure")
        c.chest(12, 3, 19, "north", loot="olympus_isles:chests/zeus_treasure")
        c.put(10, 3, 13, "quartz_block"); c.put(10, 4, 13, "gold_block")
        c.put(10, 5, 13, "lightning_rod", {"facing": "up", "powered": False, "waterlogged": False})
        for x in range(9, 12):
            for z in range(7, 12):
                c.put(x, 3, z, "light_blue_carpet")
        for (x, z) in ((8, 9), (12, 9), (8, 16), (12, 16)):
            c.lantern(x, 11, z, hanging=True)
        for (x, z) in ((8, 7), (12, 7)):
            c.put(x, 3, z, "quartz_pillar", {"axis": "y"}); c.put(x, 4, z, "campfire", {"lit": True, "facing": "north", "signal_fire": False, "waterlogged": False})

    # tesoro (tholos) al este
    flatten(c, disc(96, 62, 14))
    with c.at(96, SURF + 1, 62, 0):
        tholos(c, M, 6, 7)
        c.chest(-2, 3, 0, "east", loot="olympus_isles:chests/zeus_treasure")
        c.chest(2, 3, 0, "west", loot="olympus_isles:chests/zeus_treasure")
        c.chest(0, 3, -2, "south", loot="olympus_isles:chests/zeus_treasure")
        c.put(0, 3, 0, "gold_block")
    for x in range(CX + 21, 90):
        for z in range(CZ - 1, CZ + 2):
            c.put_w(x, SURF, z, "smooth_quartz")

    # anfiteatro al oeste
    flatten(c, disc(32, 62, 19))
    with c.at(32, SURF + 1, 62, 0):
        amphitheater(c, M, 6, 15)
    for x in range(36, CX - 20):
        for z in range(CZ - 1, CZ + 2):
            c.put_w(x, SURF, z, "smooth_quartz")

    # estanque con fuente al suroeste
    pool(c, disc(38, 92, 7), 3, "sand", rim="quartz_bricks")
    with c.at(38, SURF + 1, 92, 0):
        for dy in range(0, 4):
            c.put(0, dy, 0, "quartz_block")
        c.put(0, 4, 0, "gold_block")
    for (x, z) in ((35, 90), (41, 94), (40, 89)):
        c.put_w(x, SURF, z, "lily_pad")

    # nubes bajo el borde, olivos, cipreses y flores
    for _ in range(26):
        a = rnd.uniform(0, 2 * math.pi)
        r = rnd.uniform(46, 58)
        cx, cz, cy = int(CX + math.cos(a) * r), int(CZ + math.sin(a) * r), rnd.randint(6, 24)
        rx, ry, rz = rnd.randint(3, 6), rnd.randint(2, 3), rnd.randint(3, 6)
        for x in range(cx - rx, cx + rx + 1):
            for y in range(cy - ry, cy + ry + 1):
                for z in range(cz - rz, cz + rz + 1):
                    if ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 + ((z - cz) / rz) ** 2 <= 1 and (x, y, z) not in c.blocks:
                        c.put_w(x, y, z, "white_concrete" if (y - cy) >= 0 else "light_gray_concrete")
    for _ in range(34):
        p = free_circle(rnd, occupied, 24, 53)
        if p:
            tree(c, p[0], p[1], rnd.randint(4, 6), "oak_log", "oak_leaves", rnd, r=3)
            occupied.append((p[0], p[1], 4))
    for z in range(CZ + 24, CZ + 48, 6):
        for sx in (-9, 9):
            cypress(c, CX + sx, z, 9, rnd)
    cells = [(x, z) for (x, z) in disc(CX, CZ, 55) if keep_free(occupied, x, z, 0)]
    scatter(c, rnd, cells, FLOWERS + ["grass", "grass", "tall_grass"], 0.09)
    ensure_spawn(c, "smooth_quartz")
    return c

# =====================================================================================
#  AFRODITA
# =====================================================================================
def heart_cells(cx, cz, size):
    cells = []
    for x in range(cx - size - 2, cx + size + 3):
        for z in range(cz - size - 2, cz + size + 3):
            u = (x - cx) / size
            v = -(z - cz) / size + 0.15
            if (u * u + v * v - 1) ** 3 - u * u * v ** 3 <= 0:
                cells.append((x, z))
    return cells

def build_aphrodite():
    c = Canvas(SX, SY, SZ)
    c_ref[0] = c
    rnd = random.Random(2002)
    M = APHRODITE_M
    cfg = dict(seed=22, p1=1.1, p2=0.3, depth=40,
               top=lambda x, z, t: "moss_block" if vnoise(x, z, 7, 4) > 0.7 else "grass_block",
               sub=lambda x, z, t: "dirt",
               stone=lambda x, y, z: "stone" if _h(x, y * 3 + z, 41) > 0.25 else ("diorite" if _h(x, y, z + 9) > 0.4 else "calcite"),
               bottom=lambda x, y, z: "diorite" if _h(x, y, z) > 0.5 else "calcite")
    build_island(c, cfg)
    occupied = [(CX, CZ, 26), (CX, 26, 14), (CX - 28, 32, 8), (CX + 28, 32, 8), (CX - 40, CZ, 16), (CX + 40, CZ, 16),
                (86, 90, 16), (CX, 98, 8)]

    for (x, z) in disc(CX, CZ, 24):
        r = math.hypot(x - CX, z - CZ)
        n = "pink_terracotta" if (x + z) % 2 == 0 else "white_terracotta"
        if r > 22:
            n = "quartz_bricks"
        c.put_w(x, SURF, z, n)
    pool(c, ring(CX, CZ, 11, 15.2), 2, "smooth_quartz", rim="quartz_bricks")
    for (x, z) in ring(CX, CZ, 11, 15.2):
        if (x * 3 + z) % 7 == 0:
            c.put_w(x, SURF - 2, z, "sea_lantern")
    with c.at(CX, SURF + 1, CZ, 0):
        colossus(c, M, "aphrodite")
    for (x, z) in ((CX + 13, CZ + 2), (CX - 13, CZ - 3), (CX + 3, CZ - 13), (CX - 2, CZ + 13)):
        c.put_w(x, SURF, z, "lily_pad")

    # templo circular del amor al norte
    flatten(c, disc(CX, 26, 14))
    with c.at(CX, SURF + 1, 26, 0):
        tholos(c, M, 8, 8)
        c.chest(0, 3, -3, "south", items=[story_book("aphrodite")])
        c.chest(-3, 3, 0, "east", loot="olympus_isles:chests/aphrodite_treasure")
        c.chest(3, 3, 0, "west", loot="olympus_isles:chests/aphrodite_treasure")
        c.put(0, 3, 0, "pink_concrete"); c.put(0, 4, 0, "gold_block")
        for (dx, dz) in ((-2, -2), (2, -2), (-2, 2), (2, 2)):
            c.put(dx, 3, dz, "pink_candle", {"candles": 3, "lit": True, "waterlogged": False})
    for z in range(CZ - 25, 40, -1):
        pass
    for z in range(38, CZ - 23):
        for x in range(CX - 2, CX + 3):
            c.put_w(x, SURF, z, "smooth_quartz" if abs(x - CX) <= 1 else "pink_terracotta")

    # lago con forma de corazón y puente
    hearts = heart_cells(86, 92, 11)
    flatten(c, hearts)
    pool(c, hearts, 3, "sand", rim="cherry_planks")
    for x in range(75, 98):
        for z in (91, 92, 93):
            if (x, SURF - 1, z) in c.blocks:
                c.put_w(x, SURF, z, "cherry_planks")
                if z in (91, 93):
                    c.put_w(x, SURF + 1, z, "cherry_fence")

    # jardines de rosas a ambos lados de la plaza
    for sx in (-1, 1):
        x0 = CX + sx * 40
        flatten(c, [(x, z) for x in range(x0 - 8, x0 + 9) for z in range(CZ - 12, CZ + 13)])
        for x in range(x0 - 8, x0 + 9):
            for z in range(CZ - 12, CZ + 13):
                edge = x in (x0 - 8, x0 + 8) or z in (CZ - 12, CZ + 12)
                if edge and not (z == CZ and abs(x - x0) == 8) and not (abs(z - CZ) <= 1 and abs(x - x0) == 8):
                    for dy in range(1, 3):
                        c.put_w(x, SURF + dy, z, "flowering_azalea_leaves", {"distance": 1, "persistent": True, "waterlogged": False})
                elif (abs(x - x0) % 4 == 2) and abs(z - CZ) < 10 and abs(z - CZ) > 2:
                    double_plant(c, x, z, rnd.choice(["rose_bush", "peony", "lilac"]))
                else:
                    c.put_w(x, SURF, z, "smooth_quartz") if (abs(x - x0) <= 1 or abs(z - CZ) <= 1) else None
        with c.at(x0, SURF + 1, CZ, 0):
            fountain(c, M, 3)

    # pérgolas floridas por la avenida sur y la puerta del amor
    flatten(c, [(x, z) for x in range(CX - 9, CX + 10) for z in range(CZ + 22, CZ + 58)])
    for z in range(CZ + 25, CZ + 52):
        for x in range(CX - 2, CX + 3):
            c.put_w(x, SURF, z, "smooth_quartz" if abs(x - CX) <= 1 else "pink_terracotta")
    for z in range(CZ + 28, CZ + 48, 5):
        for sx in (-3, 3):
            for dy in range(1, 6):
                c.put_w(CX + sx, SURF + dy, z, "quartz_pillar", {"axis": "y"})
        for x in range(CX - 3, CX + 4):
            c.put_w(x, SURF + 6, z, "cherry_slab", {"type": "bottom", "waterlogged": "false"})
            c.put_w(x, SURF + 7, z, "flowering_azalea_leaves", {"distance": 1, "persistent": True, "waterlogged": False})
    with c.at(CX, SURF + 1, CZ + 50, 0):
        for sx in (-5, 5):
            for dy in range(0, 12):
                col_block(c, M, sx, dy, 0)
            c.put(sx, 12, 0, M["cap"])
        for (x, y) in [(x, y) for x in range(-6, 7) for y in range(12, 24)]:
            u, v = x / 5.4, (y - 17.0) / 5.0
            if (u * u + v * v - 1) ** 3 - u * u * v ** 3 <= 0:
                c.put(x, y, 0, "pink_concrete")
                c.put(x, y, 1, "pink_concrete")
        c.put(0, 24, 0, "gold_block")

    # templetes de jardín
    for sx in (-1, 1):
        flatten(c, disc(CX + sx * 28, 32, 8))
        with c.at(CX + sx * 28, SURF + 1, 32, 0):
            tholos(c, M, 4, 5)
            if sx == 1:
                c.chest(0, 3, 0, "south", loot="olympus_isles:chests/aphrodite_treasure")
            else:
                c.put(0, 3, 0, "pink_concrete"); c.put(0, 4, 0, "red_tulip") if False else None

    # bosques de cerezos y praderas de flores
    for _ in range(46):
        p = free_circle(rnd, occupied, 22, 53)
        if p:
            tree(c, p[0], p[1], rnd.randint(5, 7), "cherry_log", "cherry_leaves", rnd, r=3)
            occupied.append((p[0], p[1], 4))
    cells = [(x, z) for (x, z) in disc(CX, CZ, 55) if keep_free(occupied, x, z, 0)]
    scatter(c, rnd, cells, ["rose_bush", "peony", "pink_tulip", "poppy", "allium", "azure_bluet", "red_tulip",
                            "cornflower", "pink_petals", "pink_petals", "lilac"], 0.22)
    ensure_spawn(c, "smooth_quartz")
    return c

# =====================================================================================
#  HADES
# =====================================================================================
def cerberus(c, god, x, z):
    """Estatua de Cerbero: cuerpo y tres cabezas, mirando al sur."""
    box_s(c, god, x - 1, 1, z - 3, x + 1, 3, z + 1)
    box_s(c, god, x - 1, 0, z - 3, x - 1, 0, z - 2)
    box_s(c, god, x + 1, 0, z - 3, x + 1, 0, z - 2)
    box_s(c, god, x - 1, 0, z + 1, x - 1, 0, z + 1)
    box_s(c, god, x + 1, 0, z + 1, x + 1, 0, z + 1)
    for hx in (-2, 0, 2):
        box_s(c, god, x + hx - 0, 3, z + 2, x + hx + (0 if hx else 0), 4, z + 3)
        c.put(x + hx, 4, z + 4, "black_concrete") if False else None
        c.put(x + hx, 4, z + 3, "red_concrete")
        statue_block(c, x + hx, 5, z + 2, god)
    c.fill(x - 2, 3, z + 1, x + 2, 3, z + 1, "polished_blackstone")

def build_hades():
    c = Canvas(SX, SY, SZ)
    c_ref[0] = c
    rnd = random.Random(3003)
    M = HADES_M
    cfg = dict(seed=33, p1=2.2, p2=0.9, depth=46,
               top=lambda x, z, t: "coarse_dirt" if vnoise(x, z, 8, 5) > 0.68 else ("basalt" if _h(x, z, 51) > 0.8 else "blackstone"),
               sub=lambda x, z, t: "deepslate",
               stone=lambda x, y, z: "deepslate" if _h(x, y * 3 + z, 61) > 0.15 else ("tuff" if _h(x, y, z + 9) > 0.5 else "basalt"),
               bottom=lambda x, y, z: "blackstone" if _h(x, y, z) > 0.5 else "basalt")
    build_island(c, cfg)
    occupied = [(CX, CZ, 29), (CX, 22, 18), (CX - 42, CZ, 9), (CX + 42, CZ, 9), (CX, 96, 8)]

    for (x, z) in disc(CX, CZ, 20):
        r = math.hypot(x - CX, z - CZ)
        if r > 18.8:
            n = "chiseled_polished_blackstone"
        elif 10 < r <= 11:
            n = "gilded_blackstone"
        else:
            n = "polished_blackstone_bricks" if (x + z) % 2 == 0 else "polished_blackstone"
        c.put_w(x, SURF, z, n)
    # foso de lava alrededor de la plaza
    moat = ring(CX, CZ, 22.5, 26.8)
    pool(c, moat, 3, "obsidian", rim="polished_blackstone_bricks", fluid="lava")
    for (ax, az) in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        for d in range(19, 29):
            for w in range(-2, 3):
                x = CX + ax * d + (w if az else 0)
                z = CZ + az * d + (w if ax else 0)
                c.put_w(x, SURF, z, "polished_blackstone_bricks" if abs(w) < 2 else "polished_blackstone_brick_slab")
                for y in range(SURF - 3, SURF):
                    if (x, y, z) in c.blocks and c.name_at_w(x, y, z).endswith("lava"):
                        c.put_w(x, y, z, "polished_blackstone_bricks")
    with c.at(CX, SURF + 1, CZ, 0):
        colossus(c, M, "hades")
        cerberus(c, "hades", -12, 5)
    for (dx, dz) in ((15, 15), (-15, 15), (15, -15), (-15, -15)):
        with c.at(CX + dx, SURF + 1, CZ + dz, 0):
            brazier(c, 0, 0, 0, M, soul=True)

    # templo de Hades al norte
    flatten(c, [(x, z) for x in range(CX - 14, CX + 15) for z in range(10, 37)])
    for z in range(33, 36):
        pass
    with c.at(CX + 10, SURF + 1, 33, 2):
        temple(c, M, 21, 23, 9)
        c.chest(10, 3, 15, "north", items=[story_book("hades")])
        c.chest(8, 3, 15, "north", loot="olympus_isles:chests/hades_treasure")
        c.chest(12, 3, 15, "north", loot="olympus_isles:chests/hades_treasure")
        c.put(10, 3, 11, "polished_blackstone_bricks"); c.put(10, 4, 11, "soul_campfire", {"lit": True, "facing": "north", "signal_fire": False, "waterlogged": False})
        for (x, z) in ((8, 8), (12, 8), (8, 13), (12, 13)):
            c.lantern(x, 11, z, hanging=True, name="soul_lantern")
        for x in range(9, 12):
            for z in range(7, 10):
                c.put(x, 3, z, "black_carpet")

    # puertas del Tártaro al sur
    flatten(c, [(x, z) for x in range(CX - 9, CX + 10) for z in range(CZ + 26, CZ + 56)])
    for z in range(CZ + 27, CZ + 50):
        for x in range(CX - 2, CX + 3):
            c.put_w(x, SURF, z, "polished_blackstone" if abs(x - CX) <= 1 else "blackstone")
    with c.at(CX, SURF + 1, CZ + 49, 0):
        gate(c, M, 9, 13)
        for x in (-2, 0, 2):
            for dy in range(1, 6):
                c.put(x, 13 - dy + 0, 0, "chain", {"axis": "y", "waterlogged": False}) if False else None
        for x in (-3, -1, 1, 3):
            for dy in range(1, 5):
                c.put(x, 12 - dy, 0, "chain", {"axis": "y", "waterlogged": False})
            c.lantern(x, 7, 0, hanging=True, name="soul_lantern")
        for x in range(-5, 6):
            c.put(x, 14, 0, "crying_obsidian") if x % 2 == 0 else None
    for z in range(CZ + 28, CZ + 48, 6):
        for sx in (-5, 5):
            with c.at(CX + sx, SURF + 1, z, 0):
                for dy in range(0, 4):
                    c.put(0, dy, 0, "polished_basalt", {"axis": "y"})
                c.put(0, 4, 0, "soul_campfire", {"lit": True, "facing": "north", "signal_fire": False, "waterlogged": False})

    # fosos de lava con estalagmitas de basalto
    for sx in (-1, 1):
        cx0 = CX + sx * 42
        flatten(c, disc(cx0, CZ, 9))
        pool(c, disc(cx0, CZ, 5), 3, "obsidian", rim="blackstone", fluid="lava")
        for _ in range(9):
            a = rnd.uniform(0, 2 * math.pi)
            r = rnd.uniform(6, 8.5)
            x, z = int(cx0 + math.cos(a) * r), int(CZ + math.sin(a) * r)
            for dy in range(1, rnd.randint(3, 8)):
                c.put_w(x, SURF + dy, z, "basalt", {"axis": "y"})

    # asfódelos, árboles muertos, tumbas y fuegos de almas
    for _ in range(18):
        p = free_circle(rnd, occupied, 30, 53)
        if p:
            dead_tree(c, p[0], p[1], rnd.randint(5, 9), rnd)
            occupied.append((p[0], p[1], 3))
    for _ in range(14):
        p = free_circle(rnd, occupied, 30, 53)
        if p:
            x, z = p
            for dy in range(1, 4):
                c.put_w(x, SURF + dy, z, "bone_block", {"axis": "y"})
            c.put_w(x, SURF + 4, z, "skeleton_skull", {"rotation": rnd.randint(0, 15), "powered": False})
            occupied.append((x, z, 2))
    for _ in range(16):
        p = free_circle(rnd, occupied, 28, 53)
        if p:
            x, z = p
            c.put_w(x, SURF + 1, z, "polished_blackstone_bricks")
            c.put_w(x, SURF + 2, z, "chiseled_polished_blackstone")
            c.put_w(x + 1, SURF + 1, z, "polished_blackstone_brick_slab", {"type": "bottom", "waterlogged": "false"})
            occupied.append((x, z, 2))
    for _ in range(8):
        p = free_circle(rnd, occupied, 28, 53)
        if p:
            x, z = p
            for dx in range(-1, 2):
                for dz in range(-1, 2):
                    c.put_w(x + dx, SURF, z + dz, "soul_soil")
            c.put_w(x, SURF + 1, z, "soul_fire")
            occupied.append((x, z, 3))
    cells = [(x, z) for (x, z) in disc(CX, CZ, 55) if keep_free(occupied, x, z, 0)]
    scatter(c, rnd, cells, ["white_tulip", "azure_bluet", "lily_of_the_valley", "oxeye_daisy"], 0.16)
    ensure_spawn(c, "polished_blackstone_bricks")
    return c

# =====================================================================================
#  POSEIDÓN
# =====================================================================================
def ship(c, x, z):
    """Un barco de madera amarrado en la laguna (proa al este)."""
    y = SURF
    for dx in range(-6, 7):
        half = 2 - (1 if abs(dx) >= 5 else 0)
        for dz in range(-half, half + 1):
            c.put_w(x + dx, y, z + dz, "dark_oak_planks")
        for dz in (-half, half):
            c.put_w(x + dx, y + 1, z + dz, "dark_oak_planks")
    c.put_w(x + 7, y + 1, z, "dark_oak_planks"); c.put_w(x + 7, y, z, "dark_oak_planks")
    c.put_w(x - 7, y + 1, z, "dark_oak_planks"); c.put_w(x - 7, y + 2, z, "dark_oak_planks")
    for dy in range(1, 11):
        c.put_w(x, y + dy, z, "spruce_log", {"axis": "y"})
    for dy in range(3, 10):
        for dz in range(-3, 4):
            if abs(dz) <= (9 - dy) // 2 + 1:
                c.put_w(x + 1, y + dy, z + dz, "white_wool")
    c.put_w(x, y + 11, z, "blue_wool"); c.put_w(x - 1, y + 11, z, "blue_wool")
    c.lantern(x + 6, y + 2, z) if False else None

def build_poseidon():
    c = Canvas(SX, SY, SZ)
    c_ref[0] = c
    rnd = random.Random(4004)
    M = POSEIDON_M
    cfg = dict(seed=44, p1=0.7, p2=2.5, depth=42,
               top=lambda x, z, t: "sand" if t > 0.8 else "grass_block",
               sub=lambda x, z, t: "sand" if t > 0.8 else "dirt",
               stone=lambda x, y, z: "stone" if _h(x, y * 3 + z, 71) > 0.22 else ("prismarine" if _h(x, y, z + 9) > 0.4 else "dark_prismarine"),
               bottom=lambda x, y, z: "prismarine" if _h(x, y, z) > 0.4 else "dark_prismarine")
    build_island(c, cfg)
    occupied = [(CX, CZ, 25), (CX, 26, 19), (90, 70, 20), (36, 90, 9), (CX, 98, 8)]

    for (x, z) in disc(CX, CZ, 22):
        r = math.hypot(x - CX, z - CZ)
        n = "prismarine_bricks" if (x + z) % 2 == 0 else "prismarine"
        if r > 20.8:
            n = "dark_prismarine"
        c.put_w(x, SURF, z, n)
    pool(c, ring(CX, CZ, 10, 14.5), 2, "prismarine", rim="dark_prismarine")
    for (x, z) in ring(CX, CZ, 10, 14.5):
        if (x + 2 * z) % 6 == 0:
            c.put_w(x, SURF - 2, z, "sea_lantern")
    for (dx, dz) in ((18, 0), (-18, 0), (0, 18), (0, -18)):
        c.put_w(CX + dx, SURF, CZ + dz, "sea_lantern")
    with c.at(CX, SURF + 1, CZ, 0):
        colossus(c, M, "poseidon")

    # templo de Poseidón al norte
    flatten(c, [(x, z) for x in range(CX - 14, CX + 15) for z in range(10, 44)])
    with c.at(CX + 10, SURF + 1, 40, 2):
        temple(c, M, 21, 27, 9)
        c.chest(10, 3, 19, "north", items=[story_book("poseidon")])
        c.chest(8, 3, 19, "north", loot="olympus_isles:chests/poseidon_treasure")
        c.chest(12, 3, 19, "north", loot="olympus_isles:chests/poseidon_treasure")
        c.put(10, 3, 13, "prismarine_bricks"); c.put(10, 4, 13, "sea_lantern")
        for x in range(9, 12):
            for z in range(7, 12):
                c.put(x, 3, z, "cyan_carpet")
        for (x, z) in ((8, 9), (12, 9), (8, 16), (12, 16)):
            c.lantern(x, 11, z, hanging=True)

    # laguna con muelle, barco y coral
    lagoon = [(x, z) for x in range(70, 112) for z in range(52, 90)
              if math.hypot((x - 90) / 15.5, (z - 70) / 13.0) + 0.18 * (vnoise(x, z, 5, 9) - 0.5) <= 1.0]
    flatten(c, lagoon)
    pool(c, lagoon, 4, "sand", rim="sand")
    for _ in range(46):
        x, z = rnd.choice(lagoon)
        if (x, SURF - 3, z) in c.blocks and (x, SURF - 4, z) in c.blocks:
            coral = rnd.choice(["tube_coral_block", "brain_coral_block", "bubble_coral_block", "fire_coral_block", "horn_coral_block"])
            c.put_w(x, SURF - 3, z, coral)
            if rnd.random() < 0.5:
                c.put_w(x, SURF - 2, z, "sea_pickle", {"pickles": rnd.randint(1, 4), "waterlogged": True})
    for x in range(CX + 22, 92):
        for z in (69, 70, 71):
            c.put_w(x, SURF, z, "oak_planks")
            if z in (69, 71) and x % 2 == 0:
                for dy in (1, 2):
                    c.put_w(x, SURF + dy, z, "oak_fence") if dy == 1 else None
        if x % 3 == 0:
            for y in range(SURF - 3, SURF):
                c.put_w(x, y, 68, "oak_log", {"axis": "y"}); c.put_w(x, y, 72, "oak_log", {"axis": "y"})
    ship(c, 98, 78)

    # faro (Pharos) al suroeste
    flatten(c, disc(36, 90, 8))
    with c.at(36, SURF + 1, 90, 0):
        def shell(h, y1, y2, mat):
            for y in range(y1, y2 + 1):
                for x in range(-h, h + 1):
                    for z in range(-h, h + 1):
                        if max(abs(x), abs(z)) == h:
                            c.put(x, y, z, mat)
        for x in range(-5, 6):
            for z in range(-5, 6):
                for y in range(-3, 0):
                    c.put(x, y, z, "prismarine")
        shell(4, 0, 9, "prismarine_bricks")
        shell(3, 10, 29, "quartz_bricks")
        for x in range(-4, 5):
            for z in range(-4, 5):
                if max(abs(x), abs(z)) == 4:
                    c.put(x, 0, z, "dark_prismarine")
                    c.put(x, 9, z, "dark_prismarine")
        for y in range(1, 10):
            c.put(0, y, -3, "prismarine_bricks")          # respaldo de la escalera
        for y in range(1, 30):
            c.put(0, y, -2, "ladder", {"facing": "south", "waterlogged": False})
        for y in (4, 5, 14, 15, 24, 25):
            for t in (-1, 0, 1):
                c.put(4 if y < 10 else 3, y, t, "light_blue_stained_glass")
                c.put(-4 if y < 10 else -3, y, t, "light_blue_stained_glass")
        c.clear(0, 1, 4, 0, 3, 4)
        for half in ("lower", "upper"):
            c.put(0, 1 if half == "lower" else 2, 4, "oak_door",
                  {"facing": "south", "hinge": "left", "open": False, "powered": False, "half": half})
        for x in range(-3, 4):
            for z in range(-3, 4):
                c.put(x, 30, z, "dark_prismarine")
        for x in range(-3, 4):
            for z in range(-3, 4):
                if max(abs(x), abs(z)) == 3:
                    c.put(x, 31, z, "iron_bars", {"waterlogged": False})
        for x in range(-1, 2):
            for z in range(-1, 2):
                for y in range(31, 34):
                    c.put(x, y, z, "sea_lantern")
        for x in range(-2, 3):
            for z in range(-2, 3):
                if max(abs(x), abs(z)) == 2:
                    for y in range(31, 34):
                        c.put(x, y, z, "light_blue_stained_glass")
        for k in range(3):
            for x in range(-2 + k, 3 - k):
                for z in range(-2 + k, 3 - k):
                    c.put(x, 34 + k, z, "dark_prismarine")
        c.put(0, 37, 0, "sea_lantern")
        c.chest(-2, 1, 2, "south", loot="olympus_isles:chests/poseidon_treasure")

    # arena, palmeras y praderas
    for _ in range(18):
        p = free_circle(rnd, occupied, 46, 55)
        if p and c.name_at_w(p[0], SURF, p[1]) in ("minecraft:sand", "minecraft:grass_block"):
            tree(c, p[0], p[1], rnd.randint(6, 8), "jungle_log", "jungle_leaves", rnd, r=2)
            occupied.append((p[0], p[1], 3))
    for _ in range(16):
        p = free_circle(rnd, occupied, 24, 46)
        if p:
            tree(c, p[0], p[1], rnd.randint(4, 6), "oak_log", "oak_leaves", rnd, r=3)
            occupied.append((p[0], p[1], 4))
    cells = [(x, z) for (x, z) in disc(CX, CZ, 55) if keep_free(occupied, x, z, 0)]
    scatter(c, rnd, cells, ["azure_bluet", "cornflower", "oxeye_daisy", "grass", "tall_grass", "blue_orchid"], 0.08)
    ensure_spawn(c, "prismarine_bricks")
    return c

# =====================================================================================
#  MONUMENTOS del suelo (13 x 16 x 13), bajo cada isla
# =====================================================================================
MON = 13
def build_monument(M, god):
    c = Canvas(MON, 16, MON)
    cx = cz = 6
    for (x, z) in disc(cx, cz, 6.6):
        for y in range(0, 3):
            c.put_w(x, y, z, "stone_bricks")
    for (x, z) in disc(cx, cz, 6.6):
        r = math.hypot(x - cx, z - cz)
        n = M["floor"] if r <= 2.5 else (M["brick"] if r <= 4.2 else (M["floor"] if r <= 5.6 else M["base"]))
        c.put_w(x, 3, z, n)
    for x in range(MON):
        for z in range(MON):
            for y in range(4, 16):
                if (x, y, z) not in c.blocks:
                    c.put_w(x, y, z, "air")
    # pedestal, monolito y remate
    for x in range(5, 8):
        for z in range(5, 8):
            c.put_w(x, 4, z, M["base"])
    for dy in range(5, 8):
        c.put_w(6, dy, 6, "olympus_isles:password_monument", {"god": god})
    c.put_w(6, 8, 6, M["accent"])
    for (x, z) in ((5, 4), (7, 4), (5, 8), (7, 8), (4, 5), (4, 7), (8, 5), (8, 7)):
        c.stairs(x, 4, z, M["stairs"], nearest_facing(x - 6, z - 6)) if False else None
    for (x, z) in ((6, 4), (6, 8), (4, 6), (8, 6)):
        c.stairs(x, 4, z, M["stairs"], nearest_facing(6 - x, 6 - z)) if False else c.put_w(x, 4, z, M["stairs"], {"facing": nearest_facing(6 - x, 6 - z), "half": "bottom", "shape": "straight", "waterlogged": "false"})
    # pérgola de cuatro columnas
    for (x, z) in ((2, 2), (10, 2), (2, 10), (10, 10)):
        for y in range(4, 11):
            if M["col_axis"]:
                c.put_w(x, y, z, M["col"], {"axis": "y"})
            else:
                c.put_w(x, y, z, M["col"])
        c.put_w(x, 11, z, M["cap"])
    for t in range(2, 11):
        for (x, z) in ((t, 2), (t, 10), (2, t), (10, t)):
            c.put_w(x, 12, z, M["slab"], {"type": "bottom", "waterlogged": "false"}) if (x, 12, z) not in c.blocks else None
    for (x, z) in ((6, 2), (6, 10), (2, 6), (10, 6)):
        c.put_w(x, 11, z, M["light"], {"hanging": True, "waterlogged": False})
    for (x, z) in ((3, 6), (9, 6)):
        c.put_w(x, 4, z, M["base"]); c.put_w(x, 5, z, M["cap"])
        c.put_w(x, 6, z, "soul_campfire" if god == "hades" else "campfire",
                {"lit": True, "facing": "north", "signal_fire": False, "waterlogged": False})
    # escalones de entrada al sur
    for x in range(5, 8):
        c.put_w(x, 3, 11, M["stairs"], {"facing": "north", "half": "bottom", "shape": "straight", "waterlogged": "false"}) if False else None
    return c

BUILDERS = {"zeus": build_zeus, "aphrodite": build_aphrodite, "hades": build_hades, "poseidon": build_poseidon}
PALETTES = {"zeus": ZEUS_M, "aphrodite": APHRODITE_M, "hades": HADES_M, "poseidon": POSEIDON_M}
