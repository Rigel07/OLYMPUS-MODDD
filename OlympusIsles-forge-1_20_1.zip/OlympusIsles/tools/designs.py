import math, random
from lib import *
from lib import _h

SX = SZ = 125
SY = 112
CX = CZ = 62
SURF = 48            # capa superior del terreno (los edificios empiezan en SURF+1)
R_ISLAND = 57

# ------------------------------------------------------------------ paletas por dios
ZEUS_M = dict(god="zeus", base="quartz_block", brick="quartz_bricks", floor="smooth_quartz", col="quartz_pillar",
              col_axis=True, cap="chiseled_quartz_block", stairs="quartz_stairs", slab="quartz_slab",
              wall="quartz_bricks", tymp="light_blue_concrete", rstairs="quartz_stairs", rslab="quartz_slab",
              accent="gold_block", found="stone_bricks", light="lantern")
APHRODITE_M = dict(god="aphrodite", base="quartz_block", brick="quartz_bricks", floor="smooth_quartz", col="quartz_pillar",
                   col_axis=True, cap="chiseled_quartz_block", stairs="quartz_stairs", slab="quartz_slab",
                   wall="pink_terracotta", tymp="pink_concrete", rstairs="cherry_stairs", rslab="cherry_slab",
                   accent="gold_block", found="stone_bricks", light="lantern")
HADES_M = dict(god="hades", base="polished_blackstone_bricks", brick="polished_blackstone_bricks", floor="polished_blackstone",
               col="polished_basalt", col_axis=True, cap="chiseled_polished_blackstone",
               stairs="polished_blackstone_brick_stairs", slab="polished_blackstone_brick_slab",
               wall="polished_blackstone_bricks", tymp="deepslate_tiles", rstairs="blackstone_stairs",
               rslab="blackstone_slab", accent="gilded_blackstone", found="blackstone", light="soul_lantern")
POSEIDON_M = dict(god="poseidon", base="prismarine_bricks", brick="prismarine_bricks", floor="prismarine", col="prismarine_bricks",
                  col_axis=False, cap="dark_prismarine", stairs="prismarine_brick_stairs", slab="prismarine_brick_slab",
                  wall="prismarine_bricks", tymp="light_blue_concrete", rstairs="dark_prismarine_stairs",
                  rslab="dark_prismarine_slab", accent="sea_lantern", found="prismarine", light="lantern")

def statue_block(c, lx, ly, lz, god):
    c.put(lx, ly, lz, "olympus_isles:god_statue", {"god": god})

def col_block(c, M, lx, ly, lz):
    if M["col_axis"]:
        c.pillar(lx, ly, lz, M["col"], "y")
    else:
        c.put(lx, ly, lz, M["col"])

# ------------------------------------------------------------------ isla base
def build_island(c, cfg):
    seed, depth_max = cfg["seed"], cfg["depth"]
    for x in range(SX):
        for z in range(SZ):
            dx, dz = x - CX, z - CZ
            r = math.hypot(dx, dz)
            th = math.atan2(dz, dx)
            rt = R_ISLAND * (1 + 0.09 * math.sin(3 * th + cfg["p1"]) + 0.06 * math.sin(5 * th + cfg["p2"])) \
                + 6 * (vnoise(x, z, 9, seed) - 0.5)
            if r > rt:
                continue
            t = r / rt
            top = SURF
            if t > 0.6:
                top += int(round((t - 0.6) / 0.4 * 3.0 * (fbm(x, z, seed) * 2 - 0.7)))
            if t > 0.93:
                top -= int(round((t - 0.93) / 0.07 * 2.4))
            depth = int(round(depth_max * (1 - t ** 2) ** 0.75 * (0.9 + 0.2 * vnoise(x, z, 8, seed + 3)))) + 3
            if 0.15 < t < 0.85 and chance(x, 0, z, seed + 5, 0.012):
                depth += 6 + int(_h(x, z, seed + 8) * 9)
            bottom = max(top - depth, 1)
            for y in range(bottom, top + 1):
                d = top - y
                if d == 0:
                    name = cfg["top"](x, z, t)
                elif d <= 3:
                    name = cfg["sub"](x, z, t)
                elif y - bottom < 3:
                    name = cfg["bottom"](x, y, z)
                else:
                    name = cfg["stone"](x, y, z)
                c.put_w(x, y, z, name)

def flatten(c, cells, sub="dirt", top=None):
    """Deja las columnas a ras de SURF: quita lo que sobresale y rellena lo que falta."""
    for (x, z) in cells:
        for y in range(SURF + 1, SURF + 14):
            c.remove_w(x, y, z)
        if (x, SURF, z) not in c.blocks:
            y = SURF
            while y > SURF - 14 and (x, y, z) not in c.blocks:
                c.put_w(x, y, z, sub)
                y -= 1
        if top:
            c.put_w(x, SURF, z, top)

# ------------------------------------------------------------------ plantas
FLOWERS = ["poppy", "dandelion", "azure_bluet", "oxeye_daisy", "cornflower", "pink_tulip", "red_tulip",
           "white_tulip", "orange_tulip", "allium"]

def plant(c, x, z, name, props=None, y=None):
    y = SURF + 1 if y is None else y
    if (x, y, z) not in c.blocks:
        c.put_w(x, y, z, name, props)

def double_plant(c, x, z, name):
    y = SURF + 1
    if (x, y, z) not in c.blocks and (x, y + 1, z) not in c.blocks:
        c.put_w(x, y, z, name, {"half": "lower"})
        c.put_w(x, y + 1, z, name, {"half": "upper"})

def ground_ok(c, x, z, names=("grass_block", "dirt", "coarse_dirt", "podzol", "moss_block")):
    n = c.name_at_w(x, SURF, z)
    return n is not None and n.split(":")[1] in names

def scatter(c, rnd, cells, flowers, p, extra=None):
    for (x, z) in cells:
        if rnd.random() < p and ground_ok(c, x, z):
            f = rnd.choice(flowers)
            if f in ("peony", "rose_bush", "lilac", "tall_grass", "large_fern", "sunflower"):
                double_plant(c, x, z, f)
            elif f == "pink_petals":
                plant(c, x, z, f, {"facing": rnd.choice(FACINGS), "flower_amount": rnd.choice([1, 2, 3, 4])})
            else:
                plant(c, x, z, f)

def tree(c, x, z, h, log, leaves, rnd, r=3, ground=None):
    y0 = SURF + 1
    for i in range(h):
        c.put_w(x, y0 + i, z, log, {"axis": "y"})
    top = y0 + h
    for dy in range(-2, 2):
        rr = r if dy in (-1, 0) else r - 1
        if dy == 1:
            rr = max(1, r - 2)
        for dx in range(-rr, rr + 1):
            for dz in range(-rr, rr + 1):
                if abs(dx) == rr and abs(dz) == rr and rr > 1 and rnd.random() < 0.6:
                    continue
                p = (x + dx, top + dy, z + dz)
                if p not in c.blocks:
                    c.put_w(p[0], p[1], p[2], leaves, {"distance": 1, "persistent": True, "waterlogged": False})

def cypress(c, x, z, h, rnd):
    y0 = SURF + 1
    for i in range(h):
        c.put_w(x, y0 + i, z, "spruce_log", {"axis": "y"})
    for i in range(2, h + 2):
        rr = 2 if i < h * 0.55 else 1
        if i >= h:
            rr = 0
        for dx in range(-rr, rr + 1):
            for dz in range(-rr, rr + 1):
                if abs(dx) + abs(dz) <= rr + (1 if rr == 2 else 0) and (x + dx, y0 + i, z + dz) not in c.blocks:
                    c.put_w(x + dx, y0 + i, z + dz, "spruce_leaves", {"distance": 1, "persistent": True, "waterlogged": False})

def dead_tree(c, x, z, h, rnd, log="stripped_dark_oak_log"):
    y0 = SURF + 1
    for i in range(h):
        c.put_w(x, y0 + i, z, log, {"axis": "y"})
    for k in range(3):
        d = rnd.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
        by = y0 + h - 1 - k * 2
        for s in range(1, 3 + rnd.randint(0, 1)):
            c.put_w(x + d[0] * s, by + s // 2, z + d[1] * s, log, {"axis": "x" if d[0] else "z"})

# ------------------------------------------------------------------ agua
def pool(c, cells, depth, floor, rim=None, fluid="water"):
    """Excava, pone suelo y llena de agua/lava hasta un bloque por debajo del borde."""
    cellset = set(cells)
    for (x, z) in cells:
        for y in range(SURF - depth + 1, SURF + 3):
            c.remove_w(x, y, z)
        c.put_w(x, SURF - depth, z, floor)
        for y in range(SURF - depth + 1, SURF):
            c.put_w(x, y, z, fluid, {"level": 0})
        if rim:
            for dx in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    n = (x + dx, z + dz)
                    if n not in cellset and (n[0], SURF, n[1]) in c.blocks:
                        c.put_w(n[0], SURF, n[1], rim)

# ------------------------------------------------------------------ podio y estatuas
def steps(c, M, halfs, y0=0, stairs=None, base=None):
    """Podio escalonado cuadrado centrado en (0,0). Cada nivel es un cuadrado de medio lado h."""
    stairs = stairs or M["stairs"]
    base = base or M["base"]
    for i, h in enumerate(halfs):
        y = y0 + i
        for x in range(-h, h + 1):
            for z in range(-h, h + 1):
                edge = max(abs(x), abs(z)) == h
                if edge and i < len(halfs) - 1:
                    c.stairs(x, y, z, stairs, nearest_facing(-x, -z))
                else:
                    c.put(x, y, z, base)
    for x in range(-halfs[0], halfs[0] + 1):
        for z in range(-halfs[0], halfs[0] + 1):
            for y in range(-3, y0):
                c.put(x, y, z, M["found"])

def cyl(c, fn, cells, y1, y2):
    for y in range(y1, y2 + 1):
        for (x, z) in cells:
            fn(x, y, z)

def box_s(c, god, x1, y1, z1, x2, y2, z2):
    for x in range(min(x1, x2), max(x1, x2) + 1):
        for y in range(min(y1, y2), max(y1, y2) + 1):
            for z in range(min(z1, z2), max(z1, z2) + 1):
                statue_block(c, x, y, z, god)

def colossus(c, M, style):
    """Estatua colosal centrada en el origen local, mirando al sur (+z). Todo el cuerpo es god_statue."""
    god = M["god"]
    steps(c, M, [9, 7, 5, 4], 0)
    y = 4
    S = lambda x, yy, z: statue_block(c, x, yy, z, god)
    # --- parte baja
    if style == "aphrodite":
        for yy in range(y, y + 14):
            rr = 7.0 - (yy - y) * 0.2          # vestido que se abre hacia el suelo
            for (x, z) in disc(0, 0, rr):
                S(x, yy, z)
        for yy in range(y + 14, y + 18):
            for (x, z) in disc(0, 0, 4.2):
                S(x, yy, z)
    elif style == "poseidon":
        box_s(c, god, -3, y, -1, -1, y + 13, 1)
        box_s(c, god, 1, y, -1, 3, y + 13, 1)
        for yy in range(y + 10, y + 17):
            for (x, z) in disc(0, 0, 5.0 - (yy - y - 10) * 0.1):
                S(x, yy, z)
    elif style == "hades":
        for yy in range(y, y + 18):
            rr = 6.6 - (yy - y) * 0.15
            for (x, z) in disc(0, 0, rr):
                S(x, yy, z)
    else:  # zeus
        for yy in range(y, y + 17):
            for (x, z) in disc(0, 0, 5.6 - (yy - y) * 0.08):
                S(x, yy, z)
    # --- torso
    ty = y + 17
    if style == "aphrodite":
        box_s(c, god, -3, ty, -2, 3, ty + 8, 2)
        box_s(c, god, -4, ty + 9, -2, 4, ty + 10, 2)
    else:
        box_s(c, god, -4, ty, -2, 4, ty + 8, 2)
        box_s(c, god, -6, ty + 9, -2, 6, ty + 11, 2)
    head_y = ty + 12 + (1 if style != "aphrodite" else 0)
    box_s(c, god, -1, head_y - 1, -1, 1, head_y - 1, 1)       # cuello
    # --- cabeza (5 x 7 x 5)
    box_s(c, god, -2, head_y, -2, 2, head_y + 6, 2)
    c.put(-1, head_y + 4, 3, "black_concrete"); c.put(1, head_y + 4, 3, "black_concrete")   # ojos
    statue_block(c, 0, head_y + 3, 3, god)                                                  # nariz
    c.put(0, head_y + 1, 3, "black_concrete")                                               # boca
    # --- brazos y accesorios según el dios
    if style == "zeus":
        box_s(c, god, -8, ty + 1, -1, -7, ty + 11, 0)                                       # brazo izquierdo caído
        box_s(c, god, 7, ty + 9, -1, 8, ty + 18, 0)                                         # brazo derecho alzado
        c.fill(-2, head_y - 1, 3, 2, head_y + 1, 4, "white_wool")                           # barba
        c.fill(-3, head_y + 5, -3, 3, head_y + 7, 3, "white_wool")                          # cabello
        for (x, z) in ring(0, 0, 2.6, 3.6):
            c.put(x, head_y + 7, z, "gold_block")                                           # corona de laurel
        bolt = [(7, 0), (7, 1), (8, 2), (8, 3), (7, 4), (7, 5), (6, 6), (6, 7), (7, 8), (7, 9), (8, 10), (8, 11)]
        by = ty + 19
        for i, (bx, dy) in enumerate(bolt):
            c.put(bx, by + dy, 0, "gold_block"); c.put(bx + 1, by + dy, 0, "yellow_concrete")
        c.put(8, by + 12, 0, "gold_block")
        # águila a los pies
        for x in range(-6, -3):
            for z in range(3, 6):
                c.put(x, 4, z, "white_concrete")
        c.fill(-6, 5, 4, -5, 6, 4, "white_concrete"); c.put(-6, 7, 4, "white_concrete"); c.put(-7, 7, 4, "yellow_concrete")
        c.fill(-8, 5, 3, -3, 5, 3, "white_concrete")
    elif style == "poseidon":
        box_s(c, god, -8, ty + 1, -1, -7, ty + 11, 0)
        box_s(c, god, 7, ty + 9, -1, 8, ty + 18, 0)
        c.fill(-2, head_y - 1, 3, 2, head_y + 1, 4, "light_blue_wool")                       # barba de espuma
        c.fill(-3, head_y + 5, -3, 3, head_y + 7, 3, "cyan_wool")                           # cabello
        for (x, z) in ring(0, 0, 2.6, 3.6):
            c.put(x, head_y + 7, z, "gold_block")
        by = ty + 19
        for dy in range(0, 14):
            c.put(7, by + dy, 0, "dark_prismarine"); c.put(8, by + dy, 0, "dark_prismarine")
        for x in range(4, 12):
            c.put(x, by + 14, 0, "gold_block")
        for px in (4, 7, 11):
            for dy in range(15, 19):
                c.put(px, by + dy, 0, "gold_block")
        c.put(7, by + 19, 0, "sea_lantern"); c.put(4, by + 19, 0, "sea_lantern"); c.put(11, by + 19, 0, "sea_lantern")
        # caballito de mar a los pies
        for dy in range(0, 5):
            c.put(-5, 4 + dy, 4, "light_blue_concrete")
        c.fill(-6, 8, 4, -4, 8, 4, "light_blue_concrete")
    elif style == "hades":
        box_s(c, god, -8, ty + 1, -1, -7, ty + 11, 0)
        box_s(c, god, 7, ty + 6, -1, 8, ty + 11, 2)                                         # brazo derecho doblado
        c.fill(-3, head_y + 5, -3, 3, head_y + 8, 3, "black_concrete")                      # cabello
        c.fill(-2, head_y - 1, 3, 2, head_y, 4, "black_concrete")                           # barba corta
        for (x, z) in ring(0, 0, 2.0, 3.2):
            for dyy in (7, 8):
                c.put(x, head_y + dyy, z, "gold_block")                                     # corona
        for k in range(-2, 3, 2):
            c.put(k, head_y + 9, 3, "gold_block"); c.put(k, head_y + 10, 3, "gold_block")
        # bidente a su derecha, clavado en el suelo
        for dy in range(4, ty + 20):
            c.put(8, dy, 2, "blackstone"); c.put(9, dy, 2, "blackstone")
        for x in range(7, 11):
            c.put(x, ty + 20, 2, "gold_block")
        for px in (7, 10):
            for dy in range(21, 25):
                c.put(px, ty + dy - 0, 2, "gold_block")
        c.put(7, ty + 25, 2, "soul_lantern") if False else None
    elif style == "aphrodite":
        box_s(c, god, -6, ty + 5, -1, -5, ty + 10, 1)                                       # brazos doblados
        box_s(c, god, 5, ty + 5, -1, 6, ty + 10, 1)
        box_s(c, god, -6, ty + 5, 1, -3, ty + 6, 3)                                         # antebrazos hacia delante
        box_s(c, god, 3, ty + 5, 1, 6, ty + 6, 3)
        c.fill(-1, ty + 6, 3, 1, ty + 8, 4, "gold_block")                                   # manzana de oro
        c.fill(-3, head_y + 5, -3, 3, head_y + 7, 3, "pink_concrete")                       # cabello rosa
        c.fill(-3, head_y - 8, -4, 3, head_y + 4, -3, "pink_concrete")                      # melena larga
        c.fill(-2, ty - 6, -4, 2, head_y - 9, -3, "pink_wool")
        for (x, z) in ring(0, 0, 2.6, 3.6):
            c.put(x, head_y + 7, z, "red_concrete") if (x + z) % 2 == 0 else c.put(x, head_y + 7, z, "pink_concrete")
        # paloma en el hombro
        c.put(-6, ty + 12, 0, "white_concrete"); c.put(-7, ty + 12, 0, "white_concrete"); c.put(-6, ty + 13, 0, "white_concrete")
        c.put(-8, ty + 12, 0, "yellow_concrete")
        # concha en el pedestal
        for (x, z) in ring(0, 0, 6.5, 8.5):
            if z > 0:
                c.put(x, 4, z, "pink_concrete") if (x + z) % 2 == 0 else c.put(x, 4, z, "white_concrete")
    return head_y + 12

# ------------------------------------------------------------------ templo períptero
def temple(c, M, w, d, hcol, rows=None):
    """Templo con la fachada en el lado z=0 (local). Devuelve las coordenadas útiles de la cella."""
    # cimientos y gradas
    for x in range(w):
        for z in range(d):
            for y in range(-4, 0):
                c.put(x, y, z, M["found"])
    for k in range(3):
        for x in range(k, w - k):
            for z in range(k, d - k):
                edge = (x in (k, w - 1 - k)) or (z in (k, d - 1 - k))
                if k < 2 and edge:
                    fx = "east" if x == k else "west" if x == w - 1 - k else None
                    fz = "south" if z == k else "north" if z == d - 1 - k else None
                    face = fz if (fz and (not fx or abs(z - (d - 1) / 2) > abs(x - (w - 1) / 2))) else fx
                    c.stairs(x, k, z, M["stairs"], face)
                else:
                    c.put(x, k, z, M["floor"] if k == 2 else M["base"])
    # columnas
    xs = list(range(3, w - 3, 2))
    zs = list(range(3, d - 3, 2))
    cols = set()
    for x in xs:
        cols.add((x, 3)); cols.add((x, d - 4))
    for z in zs:
        cols.add((3, z)); cols.add((w - 4, z))
    for (x, z) in cols:
        for y in range(3, 3 + hcol):
            col_block(c, M, x, y, z)
        c.put(x, 3 + hcol, z, M["cap"])
    # entablamento
    e0 = 3 + hcol + 1
    perim = [(x, z) for x in range(3, w - 3) for z in range(3, d - 3) if x in (3, w - 4) or z in (3, d - 4)]
    for (x, z) in perim:
        c.put(x, e0 - 1, z, M["base"])
        c.put(x, e0, z, M["base"])
        c.put(x, e0 + 1, z, M["cap"] if (x + z) % 2 == 0 else M["base"])
    for x in range(2, w - 2):
        for z in range(2, d - 2):
            if x in (2, w - 3) or z in (2, d - 3):
                c.slab(x, e0 + 2, z, M["slab"])
    # cella
    cx = (w - 1) // 2
    for y in range(3, 3 + hcol):
        for x in range(6, w - 6):
            for z in range(6, d - 6):
                if x in (6, w - 7) or z in (6, d - 7):
                    c.put(x, y, z, M["wall"])
    for y in range(3, 3 + min(5, hcol)):
        for x in range(cx - 1, cx + 2):
            c.clear(x, y, 6, x, y, 6)
    for x in range(cx - 2, cx + 3):
        c.put(x, 3 + min(5, hcol), 6, M["cap"])
    for x in range(6, w - 6):
        for z in range(6, d - 6):
            c.put(x, 2, z, M["brick"] if (x + z) % 2 else M["floor"])
            c.slab(x, 3 + hcol, z, M["slab"], "top")
    # tejado a dos aguas
    ry = e0 + 3
    wr = w - 4
    for k in range((wr + 1) // 2):
        xl, xr = 2 + k, w - 3 - k
        y = ry + k
        for z in range(2, d - 2):
            if xl < xr:
                c.stairs(xl, y, z, M["rstairs"], "east")
                c.stairs(xr, y, z, M["rstairs"], "west")
            else:
                c.put(xl, y, z, M["rslab"] and M["base"])
        for z in (3, d - 4):
            for x in range(xl + 1, xr):
                c.put(x, y, z, M["tymp"])
    # acroteras doradas
    c.put(cx, ry + (wr + 1) // 2, 2, M["accent"])
    c.put(cx, ry + (wr + 1) // 2, d - 3, M["accent"])
    return dict(cx=cx, back=d - 8, front=7, floor=2, hcol=hcol, w=w, d=d)

# ------------------------------------------------------------------ tholos (templo circular)
def tholos(c, M, r, hcol, dome=None, door="south"):
    for (x, z) in disc(0, 0, r + 3):
        for y in range(-4, 0):
            c.put(x, y, z, M["found"])
    for k, rr in enumerate((r + 3.4, r + 2.4, r + 1.4)):
        for (x, z) in disc(0, 0, rr):
            dist_edge = rr - math.hypot(x, z)
            if k < 2 and dist_edge < 1.0:
                c.stairs(x, k, z, M["stairs"], nearest_facing(-x, -z))
            else:
                c.put(x, k, z, M["floor"] if k == 2 else M["base"])
    n = max(8, int(2 * math.pi * r / 3.2))
    pts = set()
    for i in range(n):
        a = 2 * math.pi * i / n
        pts.add((round(math.cos(a) * r), round(math.sin(a) * r)))
    for (x, z) in pts:
        for y in range(3, 3 + hcol):
            col_block(c, M, x, y, z)
        c.put(x, 3 + hcol, z, M["cap"])
    e0 = 3 + hcol + 1
    for (x, z) in ring(0, 0, r - 0.8, r + 0.8):
        c.put(x, e0 - 1, z, M["base"])
        c.put(x, e0, z, M["base"])
        c.put(x, e0 + 1, z, M["cap"] if (x + z) % 2 == 0 else M["base"])
    for (x, z) in ring(0, 0, r + 0.6, r + 1.6):
        c.slab(x, e0 + 2, z, M["slab"])
    # cella redonda con puerta al sur
    for y in range(3, 3 + hcol):
        for (x, z) in ring(0, 0, r - 3.0, r - 2.0):
            c.put(x, y, z, M["wall"])
    for y in range(3, 3 + min(5, hcol)):
        for x in (-1, 0, 1):
            for z in range(0, r + 1):
                if math.hypot(x, z) > r - 3.2 and z > 0:
                    c.clear(x, y, z, x, y, z)
    for (x, z) in disc(0, 0, r - 2.0):
        c.put(x, 2, z, M["brick"] if (x + z) % 2 else M["floor"])
    # cúpula
    rd = r + 1
    dm = dome or M["rstairs"]
    for j in range(0, rd + 1):
        rho = math.sqrt(max(0.0, rd * rd - j * j))
        for (x, z) in ring(0, 0, rho - 1.2, rho + 0.2):
            c.put(x, e0 + 3 + j, z, M["tymp"] if j % 2 == 0 else M["wall"])
    c.put(0, e0 + 3 + rd + 1, 0, M["accent"])
    c.put(0, e0 + 3 + rd + 2, 0, M["accent"])
    return dict(r=r, floor=2, hcol=hcol)

# ------------------------------------------------------------------ otros elementos
def brazier(c, lx, ly, lz, M, soul=False):
    for dy in range(3):
        c.put(lx, ly + dy, lz, M["base"])
    c.put(lx, ly + 3, lz, M["cap"])
    c.put(lx, ly + 4, lz, "soul_campfire" if soul else "campfire",
          {"lit": True, "facing": "north", "signal_fire": False, "waterlogged": False})

def amphitheater(c, M, r0, r1, half="west"):
    """Graderío en semicírculo con centro en el origen local; abierto hacia +x."""
    for r in range(r0, r1 + 1):
        k = r - r0
        for (x, z) in ring(0, 0, r - 0.5, r + 0.5):
            if x > 0:
                continue
            for y in range(-3, k):
                c.put(x, y, z, M["found"])
            c.stairs(x, k, z, M["stairs"], nearest_facing(-x, -z) if False else nearest_facing(x, z))
    for (x, z) in disc(0, 0, r0 - 1):
        for y in range(-3, 0):
            c.put(x, y, z, M["found"])
        c.put(x, 0, z, M["floor"])

def fountain(c, M, r, water="water"):
    for (x, z) in disc(0, 0, r + 0.5):
        c.put(x, -1, z, M["found"])
        c.put(x, 0, z, M["base"])
    for (x, z) in ring(0, 0, r - 1.0, r + 0.5):
        c.put(x, 1, z, M["base"])
    for (x, z) in disc(0, 0, r - 1.2):
        c.put(x, 0, z, water, {"level": 0})
        c.put(x, 1, z, water, {"level": 0}) if False else None
    for dy in range(1, 5):
        c.put(0, dy, 0, M["base"])
    c.put(0, 5, 0, M["accent"])
    for (dx, dz) in ((2, 0), (-2, 0), (0, 2), (0, -2)):
        c.put(dx, 1, dz, M["cap"])

def lamp_post(c, lx, ly, lz, M):
    c.put(lx, ly, lz, M["base"])
    for dy in range(1, 4):
        c.put(lx, ly + dy, lz, "end_rod" if M["god"] != "hades" else "chain", {"facing": "up"} if M["god"] != "hades" else {"axis": "y", "waterlogged": False})
    c.put(lx, ly + 4, lz, M["light"], {"hanging": False, "waterlogged": False})

def gate(c, M, width=9, height=10):
    """Propileo: dos grandes pilares y un dintel. Abierto a lo largo de z."""
    half = width // 2
    for sx in (-half, half):
        for dx in range(2):
            for dz in range(2):
                for y in range(0, height):
                    col_block(c, M, sx + (dx if sx > 0 else -dx), y, dz)
                c.put(sx + (dx if sx > 0 else -dx), height, dz, M["cap"])
    for x in range(-half - 1, half + 2):
        for z in range(0, 2):
            c.put(x, height + 1, z, M["base"])
            c.put(x, height + 2, z, M["cap"] if x % 2 == 0 else M["base"])
            c.slab(x, height + 3, z, M["slab"])
    for x in range(-2, 3):
        c.put(x, height + 3, 0, M["accent"]) if abs(x) == 0 else None

def stoa(c, M, length, depth=5, hcol=6):
    """Pórtico: muro trasero, hilera de columnas y techo plano. Frente hacia -z."""
    for x in range(length):
        for z in range(depth):
            c.put(x, 0, z, M["floor"])
            for y in range(-3, 0):
                c.put(x, y, z, M["found"])
    for x in range(length):
        for y in range(1, 1 + hcol):
            c.put(x, y, depth - 1, M["wall"])
    for x in range(0, length, 2):
        for y in range(1, 1 + hcol):
            col_block(c, M, x, y, 0)
        c.put(x, 1 + hcol, 0, M["cap"])
    for x in range(length):
        for z in range(depth):
            c.put(x, 2 + hcol, z, M["base"]) if z in (0, depth - 1) else c.slab(x, 2 + hcol, z, M["slab"])

def hedge(c, cells, name="azalea_leaves", h=2):
    for (x, z) in cells:
        for dy in range(h):
            p = (x, SURF + 1 + dy, z)
            if p not in c.blocks:
                c.put_w(p[0], p[1], p[2], name, {"distance": 1, "persistent": True, "waterlogged": False})

def keep_free(occupied, x, z, margin=0):
    for (ox, oz, r) in occupied:
        if math.hypot(x - ox, z - oz) < r + margin:
            return False
    return True
