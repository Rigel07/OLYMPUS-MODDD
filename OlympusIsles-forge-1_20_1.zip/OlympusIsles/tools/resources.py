import os, json, math, random, sys
sys.path.insert(0, os.path.dirname(__file__))
from PIL import Image
import islands
from lib import _h

MOD = "olympus_isles"
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RES = f"{ROOT}/src/main/resources"
A = f"{RES}/assets/{MOD}"
D = f"{RES}/data/{MOD}"
GODS = ["zeus", "aphrodite", "hades", "poseidon"]

def wjson(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

# ------------------------------------------------------------------ plantillas .nbt
def build_templates():
    for god in GODS:
        c = islands.BUILDERS[god]()
        n, p = c.save(f"{D}/structures/{god}_island.nbt")
        print(f"  {god}_island.nbt: {n} bloques, paleta {p}, fuera de limites {c.skipped}")
        m = islands.build_monument(islands.PALETTES[god], god)
        n, p = m.save(f"{D}/structures/{god}_monument.nbt")
        print(f"  {god}_monument.nbt: {n} bloques, paleta {p}")

# ------------------------------------------------------------------ texturas de los bloques
def marble(base, vein, vein2, seed):
    img = Image.new("RGBA", (16, 16))
    for y in range(16):
        for x in range(16):
            n = _h(x, y, seed)
            v = math.sin((x * 0.55 + y * 0.35) + 3.0 * _h(x // 3, y // 3, seed + 5)) * 0.5 + 0.5
            c = base
            if v > 0.86:
                c = vein
            elif v < 0.1:
                c = vein2
            k = 0.94 + 0.12 * n
            img.putpixel((x, y), tuple(min(255, int(a * k)) for a in c) + (255,))
    return img

def rune_block(base, edge, glow, glyph, seed):
    img = marble(base, tuple(min(255, a + 12) for a in base), tuple(max(0, a - 18) for a in base), seed)
    for i in range(16):
        for (x, y) in ((i, 0), (i, 15), (0, i), (15, i)):
            img.putpixel((x, y), edge + (255,))
    for (x, y) in ((1, 1), (14, 1), (1, 14), (14, 14)):
        img.putpixel((x, y), glow + (255,))
    for y, row in enumerate(glyph):
        for x, ch in enumerate(row):
            if ch == "#":
                img.putpixel((3 + x, 3 + y), glow + (255,))
            elif ch == "+":
                img.putpixel((3 + x, 3 + y), tuple(min(255, a + 70) for a in glow) + (255,))
    return img

GLYPHS = {
    "zeus": ["......#.....", ".....##.....", "....##......", "...##.......", "..#####.....", "......##....", ".....##.....", "....##......",
             "...#+.......", "..#+........", ".#..........", "............"],
    "aphrodite": ["............", "..###..###..", ".#####.####.", ".##########.", ".##########.", "..########..", "...######...", "....####....",
                  ".....##.....", "............", "............", "............"],
    "hades": ["...#....#...", "...#....#...", "...#....#...", "...##..##...", "....####....", ".....##.....", ".....##.....", ".....##.....",
              ".....##.....", ".....##.....", "............", "............"],
    "poseidon": ["...#..#..#..", "...#..#..#..", "...#..#..#..", "...########.", ".....##.....", ".....##.....", ".....##.....", ".....##.....",
                 ".....##.....", ".....##.....", "............", "............"],
}

def build_textures():
    marbles = {"zeus": ((238, 238, 240), (205, 205, 215), (250, 250, 252)),
               "aphrodite": ((250, 226, 236), (240, 170, 200), (255, 245, 250)),
               "hades": ((64, 60, 74), (120, 90, 160), (38, 34, 46)),
               "poseidon": ((222, 240, 244), (110, 200, 205), (245, 252, 255))}
    runes = {"zeus": ((230, 232, 238), (255, 215, 80), (255, 225, 90)),
             "aphrodite": ((248, 214, 228), (255, 120, 170), (255, 90, 150)),
             "hades": ((46, 42, 56), (130, 60, 190), (90, 230, 240)),
             "poseidon": ((200, 232, 232), (40, 150, 170), (60, 220, 255))}
    for i, god in enumerate(GODS):
        b, v1, v2 = marbles[god]
        marble(b, v1, v2, 100 + i).save(f"{A}/textures/block/statue_{god}.png")
        base, edge, glow = runes[god]
        rune_block(base, edge, glow, GLYPHS[god], 200 + i).save(f"{A}/textures/block/monument_{god}.png")

def build_models():
    for god in GODS:
        wjson(f"{A}/models/block/statue_{god}.json", {"parent": "minecraft:block/cube_all",
                                                      "textures": {"all": f"{MOD}:block/statue_{god}"}})
        wjson(f"{A}/models/block/monument_{god}.json", {"parent": "minecraft:block/cube_all",
                                                        "textures": {"all": f"{MOD}:block/monument_{god}"}})
    wjson(f"{A}/blockstates/god_statue.json", {"variants": {f"god={g}": {"model": f"{MOD}:block/statue_{g}"} for g in GODS}})
    wjson(f"{A}/blockstates/password_monument.json", {"variants": {f"god={g}": {"model": f"{MOD}:block/monument_{g}"} for g in GODS}})
    wjson(f"{A}/models/item/god_statue.json", {"parent": f"{MOD}:block/statue_zeus"})
    wjson(f"{A}/models/item/password_monument.json", {"parent": f"{MOD}:block/monument_zeus"})

# ------------------------------------------------------------------ botín temático de los cofres
def item(name, lo=None, hi=None, weight=10, funcs=None):
    e = {"type": "minecraft:item", "name": name, "weight": weight}
    f = []
    if lo is not None:
        f.append({"function": "minecraft:set_count",
                  "count": ({"type": "minecraft:uniform", "min": float(lo), "max": float(hi)} if hi not in (None, lo) else float(lo))})
    if funcs:
        f.extend(funcs)
    if f:
        e["functions"] = f
    return e

def pool(rolls, entries):
    r = {"type": "minecraft:uniform", "min": float(rolls[0]), "max": float(rolls[1])} if isinstance(rolls, tuple) else float(rolls)
    return {"rolls": r, "bonus_rolls": 0.0, "entries": entries}

def ench(**levels):
    return {"function": "minecraft:set_enchantments", "enchantments": {f"minecraft:{k}": v for k, v in levels.items()}}

def book(lo, hi):
    return item("minecraft:book", 1, 1, 10, [{"function": "minecraft:enchant_with_levels",
                                              "levels": {"type": "minecraft:uniform", "min": lo, "max": hi}, "treasure": True}])

def build_loot():
    common = [item("minecraft:diamond", 2, 6, 10), item("minecraft:emerald", 6, 16, 10), item("minecraft:gold_ingot", 8, 20, 12),
              item("minecraft:experience_bottle", 8, 20, 8), item("minecraft:golden_apple", 1, 3, 6)]
    tables = {
        "zeus_treasure": [
            pool((4, 6), common + [item("minecraft:lightning_rod", 2, 5, 10), item("minecraft:clock", 1, 1, 6),
                                   item("minecraft:firework_rocket", 8, 24, 8), item("minecraft:copper_block", 4, 12, 8),
                                   item("minecraft:shield", 1, 1, 5, [ench(unbreaking=3)]),
                                   item("minecraft:golden_helmet", 1, 1, 5, [ench(protection=4, unbreaking=3)])]),
            pool((1, 2), [item("minecraft:trident", 1, 1, 8, [ench(channeling=1, loyalty=3, unbreaking=3)]),
                          item("minecraft:enchanted_golden_apple", 1, 1, 6), item("minecraft:totem_of_undying", 1, 1, 6),
                          item("minecraft:netherite_ingot", 1, 2, 4), book(25, 39)])],
        "aphrodite_treasure": [
            pool((4, 6), common + [item("minecraft:rose_bush", 3, 8, 10), item("minecraft:peony", 3, 8, 10),
                                   item("minecraft:pink_petals", 8, 24, 10), item("minecraft:cherry_sapling", 2, 5, 8),
                                   item("minecraft:honey_bottle", 2, 5, 8), item("minecraft:cake", 1, 2, 6),
                                   item("minecraft:golden_carrot", 8, 20, 8), item("minecraft:pink_dye", 8, 24, 8)]),
            pool((1, 2), [item("minecraft:enchanted_golden_apple", 1, 2, 10), item("minecraft:amethyst_shard", 8, 24, 8),
                          item("minecraft:golden_chestplate", 1, 1, 6, [ench(protection=4, unbreaking=3, mending=1)]),
                          item("minecraft:name_tag", 1, 3, 6), item("minecraft:music_disc_cat", 1, 1, 3), book(25, 39)])],
        "hades_treasure": [
            pool((4, 6), common + [item("minecraft:obsidian", 6, 16, 8), item("minecraft:crying_obsidian", 4, 12, 8),
                                   item("minecraft:soul_lantern", 2, 6, 8), item("minecraft:blaze_rod", 2, 6, 6),
                                   item("minecraft:gold_block", 1, 3, 6), item("minecraft:ancient_debris", 1, 3, 5),
                                   item("minecraft:potion", 1, 2, 6, [{"function": "minecraft:set_potion", "id": "minecraft:fire_resistance"}])]),
            pool((1, 2), [item("minecraft:netherite_ingot", 1, 2, 8), item("minecraft:echo_shard", 1, 3, 6),
                          item("minecraft:wither_skeleton_skull", 1, 1, 4), item("minecraft:totem_of_undying", 1, 1, 8),
                          item("minecraft:netherite_scrap", 2, 4, 8),
                          item("minecraft:netherite_helmet", 1, 1, 3, [ench(protection=4, unbreaking=3, respiration=3)]), book(25, 39)])],
        "poseidon_treasure": [
            pool((4, 6), common + [item("minecraft:prismarine_crystals", 6, 16, 10), item("minecraft:sea_lantern", 3, 8, 8),
                                   item("minecraft:nautilus_shell", 1, 2, 6), item("minecraft:pufferfish", 3, 8, 6),
                                   item("minecraft:cod", 8, 20, 6), item("minecraft:tropical_fish", 4, 12, 6),
                                   item("minecraft:turtle_helmet", 1, 1, 5, [ench(respiration=3, aqua_affinity=1, unbreaking=3)])]),
            pool((1, 2), [item("minecraft:trident", 1, 1, 10, [ench(riptide=3, unbreaking=3, mending=1)]),
                          item("minecraft:heart_of_the_sea", 1, 1, 8), item("minecraft:conduit", 1, 1, 4),
                          item("minecraft:enchanted_golden_apple", 1, 1, 4),
                          item("minecraft:diamond_boots", 1, 1, 4, [ench(depth_strider=3, feather_falling=4, unbreaking=3)]), book(25, 39)])],
    }
    for name, pools in tables.items():
        wjson(f"{D}/loot_tables/chests/{name}.json", {"type": "minecraft:chest", "pools": pools})

# ------------------------------------------------------------------ mundo
LAND = ["#minecraft:is_forest", "#minecraft:is_taiga", "#minecraft:is_jungle", "#minecraft:is_savanna", "#minecraft:is_badlands",
        "#minecraft:is_hill", "minecraft:plains", "minecraft:sunflower_plains", "minecraft:desert", "minecraft:swamp",
        "minecraft:mangrove_swamp", "minecraft:meadow", "minecraft:snowy_plains", "minecraft:cherry_grove"]
SPECS = {"zeus": (710101, None), "aphrodite": (710202, "zeus"), "hades": (710303, "aphrodite"), "poseidon": (710404, "hades")}
BOOK_TABLES = ["simple_dungeon", "abandoned_mineshaft", "desert_pyramid", "jungle_temple", "stronghold_library",
               "stronghold_corridor", "stronghold_crossing", "woodland_mansion", "buried_treasure", "ancient_city",
               "village/village_temple", "shipwreck_treasure", "underwater_ruin_big", "pillager_outpost", "igloo_chest"]
BOOK_CHANCE = {"zeus": 0.08, "aphrodite": 0.07, "hades": 0.06, "poseidon": 0.07}

def build_world():
    wjson(f"{D}/tags/worldgen/biome/has_god_island.json", {"replace": False, "values": LAND})
    wjson(f"{D}/tags/worldgen/structure/god_islands.json", {"replace": False, "values": [f"{MOD}:{g}_island" for g in GODS]})
    for god, (salt, excl) in SPECS.items():
        wjson(f"{D}/worldgen/structure/{god}_island.json", {
            "type": f"{MOD}:god_island", "god": god, "biomes": f"#{MOD}:has_god_island",
            "step": "surface_structures", "spawn_overrides": {}, "terrain_adaptation": "none"})
        placement = {"type": "minecraft:random_spread", "spacing": 120, "separation": 50, "salt": salt}
        if excl:
            placement["exclusion_zone"] = {"other_set": f"{MOD}:{excl}_island", "chunk_count": 14}
        wjson(f"{D}/worldgen/structure_set/{god}_island.json", {
            "structures": [{"structure": f"{MOD}:{god}_island", "weight": 1}], "placement": placement})
        terms = [{"condition": "forge:loot_table_id", "loot_table_id": f"minecraft:chests/{t}"} for t in BOOK_TABLES]
        wjson(f"{D}/loot_modifiers/{god}_book.json", {
            "type": f"{MOD}:add_god_book",
            "conditions": [{"condition": "minecraft:alternative", "terms": terms}],
            "god": god, "chance": BOOK_CHANCE[god]})
    wjson(f"{RES}/data/forge/loot_modifiers/global_loot_modifiers.json", {
        "replace": False, "entries": [f"{MOD}:{g}_book" for g in GODS]})

# ------------------------------------------------------------------ textos
ES = {
    "itemGroup.olympus_isles": "Islas del Olimpo",
    "block.olympus_isles.god_statue": "Mármol de estatua divina",
    "block.olympus_isles.password_monument": "Monumento de la contraseña",
    "god.olympus_isles.zeus": "Zeus",
    "god.olympus_isles.aphrodite": "Afrodita",
    "god.olympus_isles.hades": "Hades",
    "god.olympus_isles.poseidon": "Poseidón",
    "message.olympus_isles.no_island": "Este monumento no está unido a ninguna isla.",
    "message.olympus_isles.no_island_here": "Colócate en una isla o junto a su monumento.",
    "message.olympus_isles.owned_by": "Esta isla pertenece a %s. Pídele permiso para entrar.",
    "message.olympus_isles.wrong_password": "La contraseña no es correcta.",
    "message.olympus_isles.claimed_broadcast": "¡%s ha reclamado la isla de %s!",
    "message.olympus_isles.welcome": "Bienvenido a la isla de %s.",
    "message.olympus_isles.barrier": "Una barrera divina te devuelve al suelo: no tienes permiso para entrar.",
    "message.olympus_isles.attuned": "Has sintonizado la estatua de %s. Ya puedes viajar hasta aquí desde otras estatuas.",
    "message.olympus_isles.already_attuned": "Estatua de %s sintonizada. Agáchate y tócala para viajar a otras islas.",
    "message.olympus_isles.rescued": "El dios te sostiene en el aire y te devuelve a su isla.",
    "command.olympus_isles.info": "Isla de %s - dueño: %s - invitados: %s",
    "command.olympus_isles.not_owner": "Solo el dueño de la isla puede hacer eso.",
    "command.olympus_isles.trusted": "%s ya puede entrar en tu isla.",
    "command.olympus_isles.untrusted": "%s ya no puede entrar en tu isla.",
    "command.olympus_isles.you_are_trusted": "Ahora puedes entrar en la isla de %s de %s.",
    "command.olympus_isles.password": "Contraseña de %s en este mundo: %s",
    "command.olympus_isles.unclaimed": "La isla vuelve a no tener dueño.",
    "gui.olympus_isles.password_title": "Monumento de %s",
    "gui.olympus_isles.password_hint": "Escribe la contraseña del libro",
    "gui.olympus_isles.confirm": "Ascender",
    "gui.olympus_isles.cancel": "Cancelar",
    "gui.olympus_isles.travel_title": "Viaje entre estatuas",
    "gui.olympus_isles.travel_ground": "Bajar al monumento (%s, %s)",
    "gui.olympus_isles.travel_entry": "Isla de %s (%s, %s)",
}
EN = {
    "itemGroup.olympus_isles": "Olympus Isles",
    "block.olympus_isles.god_statue": "Divine Statue Marble",
    "block.olympus_isles.password_monument": "Password Monument",
    "god.olympus_isles.zeus": "Zeus",
    "god.olympus_isles.aphrodite": "Aphrodite",
    "god.olympus_isles.hades": "Hades",
    "god.olympus_isles.poseidon": "Poseidon",
    "message.olympus_isles.no_island": "This monument is not linked to any island.",
    "message.olympus_isles.no_island_here": "Stand on an island or next to its monument.",
    "message.olympus_isles.owned_by": "This island belongs to %s. Ask for permission to enter.",
    "message.olympus_isles.wrong_password": "The password is not correct.",
    "message.olympus_isles.claimed_broadcast": "%s has claimed the island of %s!",
    "message.olympus_isles.welcome": "Welcome to the island of %s.",
    "message.olympus_isles.barrier": "A divine barrier sends you back to the ground: you have no permission to enter.",
    "message.olympus_isles.attuned": "You attuned the statue of %s. You can now travel here from other statues.",
    "message.olympus_isles.already_attuned": "Statue of %s attuned. Crouch and touch it to travel to other islands.",
    "message.olympus_isles.rescued": "The god holds you in the air and returns you to their island.",
    "command.olympus_isles.info": "Island of %s - owner: %s - guests: %s",
    "command.olympus_isles.not_owner": "Only the island's owner can do that.",
    "command.olympus_isles.trusted": "%s can now enter your island.",
    "command.olympus_isles.untrusted": "%s can no longer enter your island.",
    "command.olympus_isles.you_are_trusted": "You can now enter the island of %s of %s.",
    "command.olympus_isles.password": "%s's password in this world: %s",
    "command.olympus_isles.unclaimed": "The island has no owner again.",
    "gui.olympus_isles.password_title": "Monument of %s",
    "gui.olympus_isles.password_hint": "Type the password from the book",
    "gui.olympus_isles.confirm": "Ascend",
    "gui.olympus_isles.cancel": "Cancel",
    "gui.olympus_isles.travel_title": "Travel between statues",
    "gui.olympus_isles.travel_ground": "Go down to the monument (%s, %s)",
    "gui.olympus_isles.travel_entry": "Island of %s (%s, %s)",
}

def build_lang():
    wjson(f"{A}/lang/es_es.json", ES)
    wjson(f"{A}/lang/en_us.json", EN)

if __name__ == "__main__":
    print("plantillas:")
    build_templates()
    build_textures(); build_models(); build_loot(); build_world(); build_lang()
    print("ok")
